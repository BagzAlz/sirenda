<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class m_reg extends ci_Model
{
	
	public function __construct() {
        parent::__construct();
     	}
	
	private function _listDataFrom($nama)
	{
	
	}
	private function _uploadForm($idform,$lebel,$idadmin,$ideven)
	{	
		 $path = "file_upload/form/".$idadmin."_".$ideven;
				 if (!file_exists($path)) {
					mkdir($path);
				 }
		
		  $lokasi_file = $_FILES[$lebel]['tmp_name'];
		  $tipe_file   = $_FILES[$lebel]['type'];
		  $nama_file   = $_FILES[$lebel]['name'];
		  
		  if($tipe_file)
		  {
		   $jenis=explode("/",$tipe_file);
			$jenis=$jenis[1];
			if($jenis=="png" || $jenis=="jpg" || $jenis=="jpeg")
			{
			$jenis="jpg";
			};
		  $ip=$_SERVER['REMOTE_ADDR'];
		  $ip=str_replace(".","a",$ip);
		  $ip=str_replace(":","b",$ip);
		   $nama=$ip.$idform.str_replace(".","",$lebel).".".$jenis; //penamaan file

				 $path = "file_upload/form/".$idadmin."_".$ideven."/".$nama;
				 if (file_exists($path)) {
					unlink($path);
				 }
	
			 $target_path = "file_upload/form/".$idadmin."_".$ideven."/".$nama;
			 //
			 $path = "file_upload/form/".$idadmin."_".$ideven."/index.html";
			  $file=fopen($path,"w");
				 if (!file_exists($path)) {
					 $content_to_write = "No file!";
					fwrite($file, $content_to_write);
				    fclose($file);
				 }
			 
		  }
		  //
		if (!empty($lokasi_file)) {
		move_uploaded_file($lokasi_file,$target_path);
		return $nama;
		}
	}
		
	function dateRegister($idevent,$reg)
	{
	$reg=$this->db->query("select tgl from data_peserta where id_event='".$idevent."' and kode_registrasi='".$reg."' ")->row();
	return $reg->tgl;
	}	
	private function _cekLink($kode,$id)
	{
	$this->db->where("link",$kode);
	$this->db->where("id_admin",$id);
	return $this->db->get("data_event")->num_rows();
	}
	
	function _dataEvent($kode,$id)
	{
	$this->db->where("id_admin",$id);
	$this->db->where("link",$kode);
	$data=$this->db->get("data_event")->row();
	return $data;
	}
	
	private function _getData($kode,$id)
	{
	$dataEvent=$this->_dataEvent($kode,$id);
	$this->db->order_by("id_formulir","asc");
	$this->db->where("id_admin",$id);
	$this->db->where("id_data_form",$dataEvent->id_form);
	$db=$this->db->get("tm_formulir")->result();
	$data="";
	foreach($db as $db)
	{
	$label=str_replace(" ","_",$db->nama_form);
	
	if($db->type_form=="5"){
	$data.="_@-ahref-@_".$this->_uploadForm($db->id_formulir,$label,$id,$dataEvent->id_event)." __v||v__ ";
	}
	
	
	elseif($db->type_form=="4"){
	$val="";
	$araypil=$db->pilihan;
	$data4=explode(",",$araypil);
	$dtcekbok="";
	foreach($data4 as $op)
	{
	$hmop=$this->input->post($op);
	if(isset($hmop)){
	$op=$hmop.", ";
	}else{
	$op="";
	};
	$dtcekbok.=$op;
	};
	$dtcekbok=str_replace(",,",", ",$dtcekbok);
	$data.=substr($dtcekbok,0,-1);
	
	$data.=" __v||v__ ";
		
	}
	
	
	else{
		$data.=$this->input->post($label)." __v||v__ ";
		}
	}
	return $data;
	}
	//////////////////////////
	private function  _cekReg($kode,$id,$ip)
	{
	$event=$this->_dataEvent($kode,$id);
	$this->db->where("id_admin",$id);
	$this->db->where("id_event",$event->id_event);
	$this->db->where("ip",$ip);
	return $this->db->get("data_peserta")->num_rows();
	}
		private function _dataPeserta($admin,$id,$status)
	{
	$this->db->where("id_admin",$admin);
	$this->db->where("id_event",$id);
	$this->db->where("status",$status);
	return $this->db->get("data_peserta")->num_rows();
	}
	function saveRegister($id)
	{
	
	
	$uri=$id;
	$kode=substr($uri,0,5);
	$id=substr($uri,5,40);
	$cek=$this->_cekLink($kode,$id);	
	$cek_reg=$this->_cekReg($kode,$id,$_SERVER['REMOTE_ADDR']);	
	if($cek_reg){ echo json_encode(0); }else{
		if(!$cek){ return false; };
		$dataEvent=$this->_dataEvent($kode,$id);
		$data=$this->_getData($kode,$id);
		
		$ps1=$this->_dataPeserta($id,$dataEvent->id_event,"1");
		$ps2=$this->_dataPeserta($id,$dataEvent->id_event,"2");
		$pt=$ps1+$ps2;
		
		if($dataEvent->quota<=$pt) { return 3; }//
		$tglSkrg=date('Y-m-d H:i:s');
		if($dataEvent->batas_registrasi<=$tglSkrg){ return 4; }
		
		$ip=$_SERVER['REMOTE_ADDR'];
	$kodeIP=str_replace(":",".",$ip);
			$kodeIPsip=str_replace(".","",$kodeIP);
	$koderegpi=explode(".",$kodeIP);
	if(count($koderegpi)>0)
	{		if(count($koderegpi)>3){	$kodeReg=$koderegpi[2].$koderegpi[0].$koderegpi[3].$koderegpi[1]; }else{ $kodeReg=$kodeIPsip; };
	}else{	$kodeReg=$kodeIPsip;	};
		
	$panjangIP=strlen($kodeReg);	//
	$patokan=12;
	$getKod=$patokan-$panjangIP;
			
	$ambilAngka=substr(str_shuffle("123456789019"),0,$getKod);
	$kodeReg=$kodeReg."".$ambilAngka;
	$kodeReg=substr($kodeReg,0,12);
	if($dataEvent->acc=="1"){ $acc="0";}else{ $acc="1";};
			$data=array(
			"id_admin"=>$id,
			"data"=>$data,
			"id_event"=>$dataEvent->id_event,
			"tgl"=>date('Y-m-d H:i:s'),
			"ip"=>$ip,
			"kode_registrasi"=>$kodeReg,
			"status"=>$acc,
			);
		
		return $this->db->insert("data_peserta",$data);	
		}
	
	}
	
	
}

?>
<textarea class="form-control" style='min-height:120px'><div id="mywidget"></div>
<script type="text/javascript" src="<?php echo base_url();?>widget.js"></script>
<script type="text/javascript">
widget_form(500,550,<?php echo $id; ?>)
</script>
</textarea>
				Widget Form digunakan untuk memasang Form registrasi pada website anda<br>
				Silahkan sesuaikan dan Copy Paste Kode diatas kehalaman website anda.<br>
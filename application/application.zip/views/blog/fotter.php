	<div class="footer style-2">
            	<div class="background"><div class="stitch"></div></div>
                <div class="foot-nav-bg"></div>
            	<div class="content">
                    <div class="patch"></div>
                    <div class="blur"></div>
                    <div class="pattern">
                        <div class="container">
                        	<div class="stitcsh"></div>
                            <div class="sixteen columns">
                                <div class="first column">
                                <img src="<?php echo base_url();?>plug/img/logo3.png" width='140px'>
                                    <div class="left">
                                      
                                       
                                        <p>
                                          Barcodevent merupakan aplikasi registrasi online untuk semua jenis event yang menyediakan sistem tiket barcode
										  untuk para register dan sistem cekin dengan menscand tiket saat event dimulai.
                     					</p>
                                        <p class="extra">
                                            barcodevent juga dapat dipergunakan untuk 
											aplikasi pendaftaran atau pendataan online karena anda dapat membuat bentuk form input data
											sendiri seuai kebutuhan anda.
                                        </p>
                                    </div>
                                </div>
                                <div class="column ct" style='color:white'>
                                    <h5>Team Tekhnis:</h5>
									Telp/Wa : 0852-2128-8210<br>
									Pin BBM : 526DCF55 <br><br>
									<h5>Team Marketing:</h5>
									Telp/Wa : 0852-2128-8210<br>
									Pin BBM : 526DCF55<br>
									email : cs@barcodevent.com<br>
									
								
                                </div>

								
                                <div class="last column omega"> 
                                  
                                    <p style='color:white'>
                                  <!-- Facebook Like Badge START -->
								  <div style="width: 100%;">
								  <div style="background: #3B5998; padding: 5px;">
								  <img src="https://www.facebook.com/images/fb_logo_small.png" alt="Facebook" />
								  <img src="https://badge.facebook.com/badge/1063356920367653.100000343840075.1839421001.png" width="0" height="0" alt="" /></div><div style="background: #EDEFF4;display: block;border-right: 1px solid #D8DFEA;border-bottom: 1px solid #D8DFEA;border-left: 1px solid #D8DFEA;margin: 0px;padding: 0px 0px 5px 0px;"><div style="background: #EDEFF4;display: block;padding: 5px;"><table cellspacing="0" cellpadding="0" border="0"><tr><td valign="top"><img src="https://www.facebook.com/images/icons/fbpage.gif" alt="" /></td><td valign="top"><p style="color: #808080;font-family: verdana;font-size: 11px;margin: 0px 0px 0px 0px;padding: 0px 8px 0px 8px;"><a href="https://web.facebook.com/cepicahyana" title="Cepi Cahyana" style="color: #3B5998;font-family: verdana;font-size: 11px;font-weight: normal;margin: 0px;padding: 0px 0px 0px 0px;text-decoration: none;" target="_TOP">Cepi Cahyana</a> likes </p></td></tr></table></div><div style="background: #FFFFFF;clear: both;display: block;margin: 0px;overflow: hidden;padding: 5px;"><table cellspacing="0" cellpadding="0" border="0"><tr><td valign="middle"><a href="https://web.facebook.com/barcodeventcom" title="barcodevent.com" style="border: 0px;color: #3B5998;font-family: verdana;font-size: 12px;font-weight: bold;margin: 0px;padding: 0px;text-decoration: none;" target="_TOP"><img src="https://z-1-scontent-sin1-1.xx.fbcdn.net/v/t1.0-1/c10.0.50.50/p50x50/13690865_1063867793649899_3894200931124859939_n.png?oh=599dffd22cf46d292388aa85dc85518c&amp;oe=57EBCFFD" style="border: 0px;margin: 0px;padding: 0px;" alt="barcodevent.com" /></a></td><td valign="middle" style="padding: 0px 8px 0px 8px;"><a href="https://web.facebook.com/barcodeventcom" title="barcodevent.com" style="border: 0px;color: #3B5998;font-family: verdana;font-size: 12px;font-weight: bold;margin: 0px;padding: 0px;text-decoration: none;" target="_TOP">barcodevent.com</a></td></tr></table></div></div><div style="display: block;float: right;margin: 0px;padding: 4px 0px 0px 0px;">
								  </div></div><!-- Facebook Like Badge END -->
                                            </p>
                                   
                                    <div class="clear"></div>
                                    <span class="hr"></span>
                                    <h5>Stay in Touch</h5>
                                    <ul class="sm foot">
                                        <li class="facebook"><a href="http://facebook.com/barcodeventcom">Facebook</a></li>
                                        <li class="twitter"><a href="#twitter">LinkedIn</a></li>
                                        <li class="linkedin"><a href="#linkedin">Pinterest</a></li>
                                        <li class="pinterest"><a href="#pinterest">Pinterest</a></li>
                                        <li class="dribbble"><a href="#dribbble">Pinterest</a></li>
                                        <li class="flickr"><a href="#flickr">Pinterest</a></li>
                                        <li class="flavors"><a href="#flavors">Pinterest</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="sixteen columns alpha omega">
                        	<div class="foot-nav-bg"></div>
                            <div class="foot-nav">
                                <div class="copy">
                                    Coptyright &copy; 2016 barcodevent.com. By Empirical Themes
                                </div>
                                <div class="nav">
                                    <a href="<?php echo base_url();?>">Home</a>
                                    <a href="<?php echo base_url();?>welcome/contact">Contact Us</a>
                                    <a href="<?php echo base_url();?>welcome/tos">Terms of Service</a>
                                    
                               	</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
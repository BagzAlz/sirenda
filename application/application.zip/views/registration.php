<?php
date_default_timezone_set("Asia/Jakarta");
$con=new umum();

$uri=$this->uri->segment(3);
$link=substr($uri,0,5);
$id=substr($uri,5,40);
$con=$con->dataEvent($link,$id);

?>
<!DOCTYPE html>
<html lang="en">

<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>plug/boostrap/css/bootstrap/bootstrap.min2.css"/>
<script src="<?php echo base_url();?>plug/boostrap/js/jquery.js"></script>
<link rel="stylesheet" type="text/css" media="all" href="<?php echo base_url();?>assets/picker/daterangepicker.css" />
<script type="text/javascript" src="<?php echo base_url();?>assets/picker/moment.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/picker/daterangepicker.js"></script>

    <head>
  <meta name="google-site-verification" content="u0idO3xKwnc-v-H4E_KDQpb6GNTJUg0ykvI3VInRg4E" />
        <meta charset="utf-8">
        <title>Online Registration</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="aplikasir online">
        <meta name="author" content="">
<link href='<?php echo base_url()?>plug/images/depag.png' rel='shortcut icon' type='image/vnd.microsoft.icon'/>
        <!-- CSS -->
        <style>
        .a:hover{color:red};
        .limit{
        background-color:black;color:white;
        }
		.ket img{  width:220px;
			  height:220px;
			  border-radius:20px;
			  margin:auto;
			  -moz-box-shadow:5px 5px 10px #000;
			  -webkit-box-shadow:5px 5px 10px #000;}
        </style>
        <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=PT+Sans:400,700'>
        <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Oleo+Script:400,700'>
        <link rel="stylesheet" href="<?php echo base_url()?>plug/register/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo base_url()?>plug/register/css/style.css">

		<script type="text/javascript" src="<?php echo base_url()?>plug/paralax/js/modernizr.custom.28468.js"></script>

<script src="http://maps.google.com/maps/api/js?sensor=false&amp;libraries=places&key=AIzaSyA8V020aIxzsnq7PlhFS0a0z50wgIgW7rM" type="text/javascript"></script>
<script>
 
    if(navigator.geolocation) {
 
        function visitorLocation(position) {
            var point = new google.maps.LatLng(<?php echo $con->lat;?>, <?php echo $con->long;?>),
 
            myOptions = {
                zoom: 15,
                center: point,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            },
 
            mapDiv = document.getElementById("mapDiv"),
            map = new google.maps.Map(mapDiv, myOptions),
 
            marker = new google.maps.Marker({
                position: point,
                map: map,
                title: "You are here"
            });
        }
        navigator.geolocation.getCurrentPosition(visitorLocation);
    }
</script>

    </head>

    <body>

        <div class="header pattern bg">
            <div class="container">
                <div class="row" >
                    <div class="logo span4 red">
                 <!--    <img class="img" src="<?php echo base_url()?>plug/img/web.png" width="70px" style="position:absolute;margin-left:-130px;margin-top:5px">   
				<a href="">	<img style="margin:10px 0px 0px 0px;width:260px" src="<?php echo base_url();?>plug/img/barcodevent.png"></a>-->
                     
	 
						
                    </div>
                 <div class="links span8 register">
		<?php 
			if(isset($con->sistem_tiket)?($con->sistem_tiket):""==1){?>
          		<a href="#" class="button registerbutton" style="width:200px;height:35px">Print Ticket</a>
			<?php } ?>
		  <!---->
                    </div> 

                </div>
            </div>
        </div>
		

<?php
if(!isset($con->title)){ echo "<center> <h1 style='color:white'>  Maaf! Event Tidak Ditemukan!	  </h1></center>";	}else{ 

$batas=substr($con->batas_registrasi,0,10);
$jamBatas=substr($con->batas_registrasi,11,5);
?>

           <br>
                <div class="bg register span5" style='margin-top:-10px'>
                    <form action="#" method="post" id="formRegistrasi" enctype="multipart/form-data">
                        <h2 style="margin-left:0px"> <span class="red"><strong><img style="max-height:40px" src="<?php echo base_url();?>plug/img/Graphic1.png"></strong></span><br>
						<small>Batas registrasi <?php echo $this->tanggal->hariLengkap($batas,"/")." ".$jamBatas; ?> WIB</small>
						</h2>
                        
						
					
                        <?php
	$this->db->order_by("id_formulir","asc");
	$this->db->where("id_admin",$id);
	$this->db->where("id_data_form",$con->id_form);
	$db=$this->db->get("tm_formulir")->result();
	$data="";
	foreach($db as $db)
	{
	if($db->required=="ya"){ $required="required";}else{ $required="";};
	$label=str_replace(" ","_",$db->nama_form);
	if($db->type_form=="2"){
	$data.='	
		
		<label for="'.$label.'"><b>'.$db->nama_form.'</b></label>
		
		<textarea style="width:95%" name="'.$label.'" id="'.$label.'" '.$required.'></textarea>
		';
	}
	
	
	
	
	
	
	elseif($db->type_form=="3"){
	$val="";
	$araypil=$db->pilihan;
	$data3=explode(",",$araypil);
	
	
	$data.='
		<label for="'.$label.'"><b>'.$db->nama_form.'</b></label>
		';
	
	
	foreach($data3 as $op)
	{
	$val[str_replace(" ","_",$op)]=$op;
	}
	$array=$val;
	$data.=form_dropdown($label,$array,"", 'style="width:100%"');
	$data.='';
	
	
	}
	
	
	
	elseif($db->type_form=="4"){
	$val="";
	$araypil=$db->pilihan;
	$data4=explode(",",$araypil);
	
		
	$data.='	
		
		<label><b>'.$db->nama_form.'</b></label>
		';
		
	foreach($data4 as $op)
	{
	$data.='
	<label><input style="width:20px" type="checkbox" name="'.str_replace(" ","_",$op).'"
	id="ra'.str_replace(" ","_",$op).'" value="'.str_replace(" ","_",$op).'" >'. $op.'	
	</label>';
	};
	
		
		
		
	
		
	}
	
	
	elseif($db->type_form=="7"){
	$val="";
	$araypil=$db->pilihan;
	$data7=explode(",",$araypil);
	
		

	$data.="<label><b>".$db->nama_form."</b></label>";
	$data.="<div style='padding-bottom:10px'>";
	foreach($data7 as $op)
	{
	$data.='
	<label><input style="width:20px" type="radio" '.$required.' name="'.str_replace(" ","_",$db->nama_form).'"
	id="ra'.str_replace(" ","_",$op).'" value="'.str_replace(" ","_",$op).'" >'. $op.'	
	</label>';
	}	
		
	$data.="</div>";	
		
	
		
	}elseif($db->type_form=="5"){
		$data.='	
		<label><b>'.$db->nama_form.'</b></label>
		<input type="file" name="'.$label.'" class="form-control" id="'.$label.'" '.$required.'><br><br>
		';
	}elseif($db->type_form=="6"){
		$data.='	
		<label><b>'.$db->nama_form.'</b></label>
		<input type="text" class="form-control" name="'.$label.'" id="datesingle" '.$required.'>
	';
	}else{
	$data.='	
		<label><b>'.$db->nama_form.'</b></label>
		<input type="text" name="'.$label.'" class="form-control" id="'.$label.'" '.$required.'>
		';
	
	}
	}
	echo $data;
	?>
	                           
                       <div id="inforeg1"></div>
                        <button onclick="javascript:save()" type="submit">SIMPAN</button>
					</form>	
                    <script type="text/javascript">
		
				$('#datesingle').daterangepicker({
			"singleDatePicker": true,
			locale: {
					format: 'DD/MM/YYYY'
				}
				});
	 </script>
                </div>
 
	
	
	    <div class="register-container containers" style="margin-top:-20px">
            <div id="text">
          
		  
		  
		    <div class="container span8 ket">

			
<?php echo $con->ket;?>		
		  
            </div>
			
        </div>
	
	<?php } ?>
	
        <!-- Javascript -->
        <script src="<?php echo base_url()?>plug/register/js/jquery-1.8.2.min.js"></script>
        <script src="<?php echo base_url()?>plug/register/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url()?>plug/register/js/jquery.backstretch.min.js"></script>
        <script src="<?php echo base_url()?>plug/register/js/scripts.js"></script>
       



<script>
$("#modalcek").hide();

$(document).ready(function(){

$(".login").hide();
   $(".registerbutton").click(function(){
	modalCek();
}); 

});

function modalCek()
{
	$.ajax({
				url: "<?php echo site_url("on/modalcek/")?>",
				type: "POST",
				data:"",
				success: function(data)
				{	//alert(data);
					
							$("#modalcek").modal("show");
							$("#Isimodalcek").html(data);
							
				},
				error: function (jqXHR, textStatus, errorThrown)
				{
					alert('Error get data from ajax');
				}
			});
}
function modalSorry()
	{
	$.ajax({
				url: "<?php echo site_url("on/modalSorry/")?>",
				type: "POST",
				data:"",
				success: function(data)
				{	//alert(data);
					
							 $("#modalSorry").modal("show"); 
							$(".modalSorry").html(data);
							
				},
				error: function (jqXHR, textStatus, errorThrown)
				{
					alert('Error get data from ajax');
				}
			});

	}
	function modaltutup()
	{
	$.ajax({
				url: "<?php echo site_url("on/modaltutup/")?>",
				type: "POST",
				data:"",
				success: function(data)
				{	//alert(data);
					
					 $("#modaltutup").modal("show"); 
					  $(".modaltutup").html(data);
							
				},
				error: function (jqXHR, textStatus, errorThrown)
				{
					alert('Error get data from ajax');
				}
			});
	 
	}
	 function quota()
	{
	$.ajax({
				url: "<?php echo site_url("on/modalQuota/")?>",
				type: "POST",
				data:"",
				success: function(data)
				{	//alert(data);
					
					  $("#modalQuota").modal("show"); 
					  $(".modalQuota").html(data);
							
				},
				error: function (jqXHR, textStatus, errorThrown)
				{
					alert('Error get data from ajax');
				}
			});
	 
	}
function goCek()
{
   $('#hasilCek').html('<img style="max-width:30px;position:absolute" src="<?php echo base_url()?>plug/img/loader.gif" /> Please Wait ... ');
	var id = $('#idRegister').val();	
	var captcha = $('.captcha').val();	
		$.ajax({
				url: "<?php echo site_url("on/cek_register/".$this->uri->segment(3)."")?>",
				type: "POST",
				data:"id="+id,
				success: function(data)
				{	//alert(data);
					
							$("#hasilCek").html(data); 
							
				},
				error: function (jqXHR, textStatus, errorThrown)
				{
					alert('Error get data from ajax');
				}
			});
}


</script>
</body>
</html>






 <!-- Bootstrap modal -->
  <div class="modal fade" id="modalcek" role="dialog">
  <span id="Isimodalcek">
		
  </span> 
  </div><!-- /.modal -->
  <!-- End Bootstrap modal -->





  

  
  
  
<style type="text/css">
#text {
	text-align:center;

	-webkit-tranform:translateZ(0);
	-webkit-transition-duration:0.05s;
	-moz-tranform:translateZ(0);
	color:#f3f3f3;
	text-shadow:0 0 1px rgba(0,0,0,.2);
}

</style>
<script src="<?php echo base_url('plug/jqueryform/jquery.form.js');?>"></script>
<script>
function save()
    {
       $('#inforeg1').html("<img style='max-width:30px' src='<?php echo base_url();?>plug/img/load.gif'> <font color='#999999'>Please wait...</font>");
      var  url = "<?php echo base_url();?>on/saveRegister/<?php echo $uri;?>";
       // ajax adding data to database
          $('#formRegistrasi').ajaxForm({
            url : url,
            type: "POST",
            data: $('#formRegistrasi').serialize(),
            dataType: "JSON",
            success: function(data)
            {
               //if success close modal and reload ajax table
			  $('#formRegistrasi')[0].reset();
			  if(data=="0") {
					$('#inforeg1').html("Maaf! Anda sudah pernah mendaftar");
					DontAccept();
							 }else if(data=="3") {		 
					quota();
							 }else if(data=="4") {		 
					modaltutup();
							 }else{
					$('#inforeg1').html("Success! Silahkan Cetak Tiket anda di menu Print Ticket");			 
					Accept();
							 }
							 $("#inforeg1").html("");
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
              alert('Mohon maaf kami sedang melakukan perbaikan\nTerimakasih atas pengertiannya.');
            }
        });
    }
	
</script>

  <!-- Bootstrap modal -->
  <div class="modal fade" id="modalSorry" role="dialog" style="">
  <span class="modalSorry">
		
	</span>	 
    </div><!-- /.modal -->
  <!-- End Bootstrap modal -->  <!-- Bootstrap modal -->
  <div class="modal fade" id="modalQuota" role="dialog">
  <span class="modalQuota">
		
	 </span>
    </div><!-- /.modal -->
  <!-- End Bootstrap modal -->  
  <!-- End Bootstrap modal -->  <!-- Bootstrap modal -->
  <div class="modal fade" id="modaltutup" role="dialog" >
  <span class="modaltutup">	 </span>
  </div><!-- /.modal -->
  <!-- End Bootstrap modal -->  
  
  
  
  <!-- Bootstrap modal -->
  <div class="modal fade" id="modalsuccess" role="dialog" >
		<div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">
					<?php if(isset($con->sistem_tiket)?($con->sistem_tiket):""==1){ echo "Mohon disimpan Nomor Registrasi anda"; }else{ echo "Terimakasih"; } ?></h4>
                  </div>
                  <div class="modal-body">
				  <center>
				 <div id="pegID"></div>
				 </center>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default pull-right" data-dismiss="modal">Close</button>
                  </div>
                </div><!-- /.modal-content -->
         </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
  <!-- End Bootstrap modal -->
  
  <script>
	
 $("#modalsuccess").hide();
	
  function DontAccept()
	{
	  modalSorry()
	}
function Accept()
{
			$.ajax({
				url: "<?php echo site_url("on/success/".$this->uri->segment(3)."/".$_SERVER['REMOTE_ADDR']."")?>",
				type: "POST",
				success: function(data)
				{	//alert(data);
				 $("#modalsuccess").show();
					 $("#modalsuccess").modal("show"); 
					 $("#pegID").html(data); 
				},
				error: function (jqXHR, textStatus, errorThrown)
				{
					alert('Error get data from ajax');
				}
			});
}
	</script>
	<?php
	$bts=$con->batas_registrasi;
	if($bts<=date('Y-m-d H:i:s'))
	{
	echo "<script>alert('Maaf! Registrasi sudah ditutup.')</script>";
echo '<script> $("select").prop("disabled", true); </script>';
echo '<script> $("textarea").prop("disabled", true); </script>';
echo '<script> $("input").prop("disabled", true); </script>';
echo '<script> $("option").prop("disabled", true); </script>';
echo '<script> $("button").prop("disabled", true); </script>';
	}elseif($con->status==0){
echo "<script>alert('Event ini belum dibayar, Mohon segera melakukan pembayaran.')</script>";
echo '<script> $("select").prop("disabled", true); </script>';
echo '<script> $("textarea").prop("disabled", true); </script>';
echo '<script> $("input").prop("disabled", true); </script>';
echo '<script> $("option").prop("disabled", true); </script>';
echo '<script> $("button").prop("disabled", true); </script>';
};
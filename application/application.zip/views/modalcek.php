<div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title stik">Cetak Tiket Anda disini</h4>
                  </div>
                  <div class="modal-body">
				  <center>
				  <div class="mcek">
				 <div class="red">
               		<center> <span class="black" style="font-size:19px">Masukan Nomor Registrasi Anda</span> </center><br>
                   
				 </div>
				 <hr width="50%" style="margin-top:-20px">
				<form action="javascript:goLogin(event)" name="form" id="form" method="post">
					<input style='height:30px;margin-top:-18px' type="text" required name="idRegister" id="idRegister"/>
				</div>	
							<div id="hasilCek"></div>		
				</center>
			
                  </div>
                  <div class="modal-footer" style="z-index:-543">
                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
					<span id="infologin"></span>
                   <button class="print btn btn-info fa-save bprint">Print</button>
                    <button type="button" class="gck btn btn-danger" onclick="javascript:goCek()">Cek</button>
					</form>
                  </div>
                </div><!-- /.modal-content -->
         </div><!-- /.modal-dialog -->
		 <script>
		 $(".bprint").hide();
		 </script>
<ul class="dropdown-menu">


<?php
$dbm=$this->db->query("select mode from data_event where id_event='".$this->uri->segment(3)."'")->row();
$dbm=isset($dbm->mode)?($dbm->mode):1;
if($dbm==1)
{?>
<li><a href="<?php echo base_url();?>profile"><i class="fa fa-user"></i>Profile</a></li>
<?php } ?>
<li><a href="<?php echo base_url();?>login/logout"><i class="fa fa-power-off"></i>Logout</a></li>
</ul>


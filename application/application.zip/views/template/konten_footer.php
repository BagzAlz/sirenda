<?php $con=new konfig(); ?> 

<footer id="footer-bar" class="row">
<p id="footer-copyright" class="col-xs-12">
<?php echo $con->dataKonfig(8);?>
</p>
</footer>

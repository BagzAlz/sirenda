<?php $con=new konfig(); ?> 
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
<title>  <?php echo $con->konfigurasi(2); ?> </title>
 
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>plug/boostrap/css/bootstrap/bootstrap.min.css"/>
 
<script src="<?php echo base_url();?>plug/boostrap/js/demo-rtl.js"></script>
<script src="<?php echo base_url();?>plug/boostrap/js/jquery.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>plug/boostrap/css/libs/font-awesome.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>plug/boostrap/css/libs/nanoscroller.css"/>
 
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>plug/boostrap/css/compiled/theme_styles.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>plug/boostrap/css/libs/nifty-component.css"/>
<link rel="stylesheet" href="<?php echo base_url();?>plug/boostrap/css/libs/select2.css" type="text/css"/>
 
<link type="image/x-icon" href="<?php echo base_url();?>file_upload/img/<?php echo $con->konfigurasi(1); ?> " rel="shortcut icon"/>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,600,700,300|Titillium+Web:200,300,400' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" media="all" href="<?php echo base_url();?>assets/picker/daterangepicker.css" />
      <script type="text/javascript" src="<?php echo base_url();?>assets/picker/moment.js"></script>
      <script type="text/javascript" src="<?php echo base_url();?>assets/picker/daterangepicker.js"></script>
	  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>plug/boostrap/css/libs/summernote.min.css"/>
<?php

?>

<style>
.spesial{
text-shadow: 2px 2px 2px #999999;
}
.sadow{
text-shadow: 1px 1px 1px #999999;
}.sadow05{
text-shadow: 0.5px 0.5px 0.5px #999999;
}
.black{
color:black;
}
.size{
font-size:14px;
}
.tabel{
width:100%;
 font-family: times;
}
.tabel tr td
{
padding:2px;
padding-left:6px;
}
.thead{
padding:5px;
}
.b{
font-weight:bold;}
</style>
<!--[if lt IE 9]>
		<script src="js/html5shiv.js"></script>
		<script src="js/respond.min.js"></script>
	<![endif]-->

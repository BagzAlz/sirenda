<!-- Bootstrap modal -->
  <div class="modal fade" id="rekening" role="dialog" >
		<div class="modal-dialog">
           		
				<!----------------------------------->
				<div class="col-lg-12">
<div class="main-box clearfix">
<header class="main-box-header clearfix">

<h2 class="black sadow" >Nomor Rekening Pembayaran <button data-dismiss="modal"  class="md-close close">&times;</button>	</h2>
</header>
<div class="main-box-body clearfix">
<div class="table-responsive">
<table class="table table-products table-hover">
<tbody>
<tr>
<td>
<img src="<?php echo base_url();?>plug/img/bca.png" width="75px" alt=""/>
</td>
<td class="black">
<span class="name" style="font-size:18px">
0550-986-957
</span>
<span class="price" style="font-size:15px">
a.n Cepi cahyana
</span>
<span class="warranty" style="font-size:15px">
<i class="fa fa-certificate"></i> cabang Kab.SUBANG
</span>
</td>
</tr>
<tr>
<td>
<img src="<?php echo base_url();?>plug/img/bni.png" width="75px" alt=""/>
</td>
<td class="black">
<span class="name" style="font-size:18px">
0261-587-261
</span>
<span class="price" style="font-size:15px">
a.n Cepi cahyana
</span>
<span class="warranty" style="font-size:15px">
<i class="fa fa-certificate"></i> cabang Kab.SUBANG
</span>
</td>
</tr>
<tr>
<td>
<img src="<?php echo base_url();?>plug/img/paypal.png" width="75px" alt=""/>
</td>
<td class="black">
<span class="name" style="font-size:18px">
cahyanacepi@gmail.com
</span>
</td>
</tr>
</tbody>
</table>
<center><span class="black sadow">setelah melakukan transfer mohon konfirmasi</span></center>
</div>
</div>
</div>
</div>

				<!----------------------------------->
				<div>
				
				</div>
		</div>
		</div>		
   </div><!-- /.modal-dialog -->
<!-- End Bootstrap modal -->

<div id="warning"></div>
<?php
if($this->session->userdata("level")=="user"){
$umum=new umum();
if($umum->jmlInvoice()>0){
?>

<script>
$(document).ready(function() {
warning();
});

</script>

<?php } } ?>

<script>
function konfirm()
{
		$.ajax({
            url : "<?php echo base_url();?>payment/konfirm",
            type: "POST",
            success: function(data)
            {
             $("#konfirmasi").modal("show");
              $("#loadKonfirm").html(data);
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error adding / update data');
            }
        });
}
function closeWarning()
{
 $("#warning").html('');
}
function warning(hal)
{
		$.ajax({
            url : "<?php echo base_url();?>payment/warning/"+hal,
            type: "POST",
            success: function(data)
            {
             $("#warning").html(data);
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error adding / update data');
            }
        });
}
</script>
<!-- Bootstrap modal -->
  <div class="modal fade" id="konfirmasi" role="dialog" >
		<div class="modal-dialog">
		<div id="loadKonfirm"></div>
         </div>
   </div>
<!---------------------->



<!---------------------->
<script>
function rek()
{
$("#rekening").modal("show");
}
</script>



<?php
if($this->session->userdata("level")=="admin"){?>
<!------------------------------------------------------------------>
<script>
setInterval(function(){ notifikasi(); }, 3000);

function notifikasi()
{
	$.ajax({
            url : "<?php echo base_url();?>data_dashboard/notifikasi",
            type: "POST",
            success: function(data)
            {
             $("#notif").html(data);
            }
        });
}

</script>

<div id="notif"></div>
<!------------------------------------------------------------------>
<?php }?>



<script src="<?php echo base_url();?>plug/boostrap/js/demo-skin-changer.js"></script>  
<!--<script src="<?php echo base_url();?>plug/boostrap/js/jquery.js"></script>-->
<script src="<?php echo base_url();?>plug/boostrap/js/bootstrap.js"></script>
<script src="<?php echo base_url();?>plug/boostrap/js/jquery.nanoscroller.min.js"></script>
<script src="<?php echo base_url();?>plug/boostrap/js/demo.js"></script>  
 
<script src="<?php echo base_url();?>plug/boostrap/js/jquery.maskedinput.min.js"></script>
<!---<script src="<?php echo base_url();?>plug/boostrap/js/moment.min.js"></script>--->
<script src="<?php echo base_url();?>plug/boostrap/js/select2.min.js"></script>
<script src="<?php echo base_url();?>plug/boostrap/js/hogan.js"></script>
<script src="<?php echo base_url();?>plug/boostrap/js/typeahead.min.js"></script>
<script src="<?php echo base_url();?>plug/boostrap/js/jquery.pwstrength.js"></script>
 
<script src="<?php echo base_url();?>plug/boostrap/js/scripts.js"></script>
<script src="<?php echo base_url();?>plug/boostrap/js/pace.min.js"></script>
<script src="<?php echo base_url();?>plug/boostrap/js/modalEffects.js"></script>
<script src="<?php echo base_url();?>plug/boostrap/js/classie.js"></script>
<script src="<?php echo base_url();?>plug/boostrap/js/summernote.min.js"></script>

	 
	  
	  
	  <script>
	$(function($) {
		//tooltip init
		$('#exampleTooltip').tooltip();

		//nice select boxes
		$('#sel2').select2();
		
		$('#sel2Multi').select2({
			placeholder: 'Select a Country',
			allowClear: true
		});
	
		//masked inputs
		$("#maskedDate").mask("99/99/9999");
		$("#maskedPhone").mask("(999) 999-9999");
		$("#maskedPhoneExt").mask("(999) 999-9999? x99999");
		$("#maskedTax").mask("99-9999999");
		$("#maskedSsn").mask("999-99-9999");
		
		$("#maskedProductKey").mask("a*-999-a999",{placeholder:" ",completed:function(){alert("You typed the following: "+this.val());}});
		
		$.mask.definitions['~']='[+-]';
		$("#maskedEye").mask("~9.99 ~9.99 999");
	
		
		//autocomplete simple
		$('#exampleAutocompleteSimple').typeahead({                              
			prefetch: '/data/countries.json',
			limit: 10
		});
		
		//autocomplete with templating
		$('#exampleAutocomplete').typeahead({                              
			name: 'twitter-oss',                                                        
			prefetch: '/data/repos.json',                                             
			template: [                                                              
				'<p class="repo-language">{{language}}</p>',                              
				'<p class="repo-name">{{name}}</p>',                                      
				'<p class="repo-description">{{description}}</p>'                         
			].join(''),                                                                 
			engine: Hogan                                                               
		});
		
		
		
	});
	</script>
	
	
	
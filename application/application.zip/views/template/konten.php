<?php 
if(isset($konten)){
echo $this->load->view($konten); 
}else{	echo "File Konten Tidak Ada";}; ?>
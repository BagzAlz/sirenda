<!DOCTYPE html>
<html>
<head>
<?php $this->load->view("template/head");?>

</head>
<body>
<div id="theme-wrapper">
<?php $this->load->view("template/header");?>
</div>
<?php
$dbm=$this->db->query("select mode from data_event where id_event='".$this->uri->segment(3)."'")->row();
$dbm=isset($dbm->mode)?($dbm->mode):1;
if($dbm==1)
{?>
<div id="page-wrapper" class="container">
			<?php $this->load->view("template/sidebar");?>
</div>
<?php } ?>

<?php
if($dbm==1)
{?>
<div id="content-wrapper">
<?php }else{ ?>
<div>
<br><br><br>
<?php } ?>
 <div class="row">
			<?php $this->load->view("template/konten");?>
			<?php $this->load->view("template/konten_footer");?>
</div>


</div>

<?php $this->load->view("template/setting");?>
</body>
<?php $this->load->view("template/footer");?>
</html>
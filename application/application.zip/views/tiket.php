<?php
$uri=$this->uri->segment(3);
	$kode=substr($uri,0,5);
	$id=substr($uri,5,40);
	$E=$this->reg->_dataEvent($kode,$id);
?>
<script type="text/javascript" src="<?php echo base_url();?>plug/js/printArea.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>plug/js/barcode.js"></script>

	<link rel="stylesheet" href="<?php echo base_url();?>plug/css/styleTiketPrint.css" type="text/css"  media="print"/>
	<link rel="stylesheet" href="<?php echo base_url();?>plug/css/styleTiket.css" type="text/css" media="screen"/>
	<link href='http://fonts.googleapis.com/css?family=Questrial|Droid+Sans|Alice' rel='stylesheet' type='text/css'>
 <script type="text/javascript">
  $(".bprint").show();
  $(".mcek").hide();
  $(".gck").hide();
  $(".stik").html("Selamat! Silahkan print tiket anda");
      function generateBarcode(){ 
	        var settings = {
			output:"bmp",
          bgColor: "#f9f9f9",
       //   color: $("#color").val(),
          barWidth: 2,
          barHeight:33,
        //  moduleSize: $("#moduleSize").val(),
         //posX:12,
        //  posY: $("#posY").val(),
        //  addQuietZone: $("#quietZoneSize").val()
        };

          $("#barcodeTarget").html("").show().barcode("<?php echo $this->input->post("id"); ?>", "code128",settings);
          }
          
		   
   $(function(){   generateBarcode();     });
  
  
    </script>
  </head>
<br>
 <span  id="printTiket" >
   <img id="img" src="<?php echo base_url();?>plug/css/f/bg.jpg">
<div id="tabel" align="center" class="c2">
  <div id="content">

  	   <center>
         <div class="cv" align="center"><br>
		 <div class="ucapan">We Are Waiting You In</div>
<div class="ribbontd atas" style='margin-top:-5px'><strong class="f ribbontd-content"><font color='black'><?php echo $E->title; ?></font></strong></div>
<p style='margin-top:-70px' class="place f atas">  <?php echo $this->tanggal->aturHari2($E->startdate,$E->enddate,"/"," s/d "); ?>
<br>  <?php echo $E->lokasi; ?></p>
</div>
 
			
<span class="f cream">   <div id="barcodeTarget" class="barcodeTarget" ></div>
ID : <?php echo $idp=$this->input->post("id"); ?></span>
<br>
<?php
$con=new umum();
?>
<h3><?php echo $con->ketPeserta($idp);?> </h3>
	</center>
	<br>
	<p class="date vertikal"><b>	 printed on <?php echo date('Y-m-d'); ?> </b></p>
	</div>

</div>
</span>	
	<script>
        (function($) {
            // fungsi dijalankan setelah seluruh dokumen ditampilkan
            $(document).ready(function(e) {
                 
                // aksi ketika tombol cetak ditekan
                $(".print").bind("click", function(event) {
                    // cetak data pada area <div id="#data-mahasiswa"></div>
                    $('#printTiket').printArea();
                });
            });
        }) (jQuery);
    </script>
<?php
 $data=$this->data_kalender->dataEvent($id);
?>

<script src="http://maps.google.com/maps/api/js?sensor=false&amp;libraries=places&key=AIzaSyA8V020aIxzsnq7PlhFS0a0z50wgIgW7rM" type="text/javascript"></script>
<script>
 
    if(navigator.geolocation) {
 
        function visitorLocation(position) {
            var point = new google.maps.LatLng(<?php echo $data->lat;?>, <?php echo $data->long;?>),
 
            myOptions = {
                zoom: 15,
                center: point,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            },
 
            mapDiv = document.getElementById("mapDiv"),
            map = new google.maps.Map(mapDiv, myOptions),
 
            marker = new google.maps.Marker({
                position: point,
                map: map,
                title: "You are here"
            });
        }
        navigator.geolocation.getCurrentPosition(visitorLocation);
    }
</script>
<style>
#mapDiv {
    width:120px;
    height:120px;
    border:1px solid #efefef;
    margin:auto;
    -moz-box-shadow:5px 5px 10px #000;
    -webkit-box-shadow:5px 5px 10px #000;
}
</style>
</head>







<div class="col-lg-12 col-md-12 col-sm-12">

<div class="main-box clearfix profile-box-menu">
<div class="main-box-body clearfix">
<div class="profile-box-header clearfix" style="background-image: url(<?php echo base_url();?>plug/boostrap/img/samples/nature.jpg);">
<div id="mapDiv" class="profile-img img-responsive" ></div>
<h2 style='margin-left:10px'><?php echo $data->title; ?></h2>
<div class="job-position">
<span  style='margin-left:10px'><i class="fa fa-map-marker"></i> <?php echo $data->lokasi;?></span><br>
<span  style='margin-left:10px'><i class="fa fa-phone"></i> <?php echo $data->info_kontak;?></span><br>
<span  style='margin-left:10px'><i class="fa fa-calendar fa-lg"></i> <?php echo $this->tanggal->aturHari($data->startdate,$data->enddate,"/"," s/d ");?></span>
</div>
</div>
<div class="profile-box-content clearfix">
<ul class="menu-items">
<li>
<a href="#" class="clearfix">
<i class="fa fa-globe fa-lg"></i> Status Event
<span class=' pull-right'><?php echo $data->status_event;?></span>
</a>
</li>
<li>
<a href="#" class="clearfix">
<i class="fa fa-user fa-lg"></i> Quota Peserta
<span class=' pull-right'><?php echo $data->quota;?></span>
</a>
</li>
<li>
<a href="#" class="clearfix">
<i class="fa fa-group fa-lg"></i> Peserta terverifikasi
<span class=' pull-right'><?php echo $this->data_kalender->jmlPeserta($id); ?></span>
</a>
</li>
<li>
<a href="#" class="clearfix">
<i class="fa fa-calendar fa-lg"></i> Tanggal Registrasi Peserta
<span class=' pull-right'><?php echo $this->tanggal->range_($data->batas_registrasi," s/d ");?></span>
</a>
</li>
<li>
<a href="#" class="clearfix">
<i class="fa fa-file-text-o fa-lg"></i> Form yang digunakan 
<span class='pull-right' ><?php echo $this->data_kalender->namaForm($data->id_form); ?></span>
</a>
</li>
<li>
<a href="#" class="clearfix black">
<i class="fa fa-check-square fa-lg"></i> Proses Verifikasi Peserta
<span class=' pull-right'><?php  if($data->acc==1){ echo "YA"; }else{ echo "Tidak";}; ?></span>
</a>
</li>
<li></li>
</ul>

</div>
</div>
<p style="padding:10px"><?php  echo $data->ket; ?></p>
</div>
</div>




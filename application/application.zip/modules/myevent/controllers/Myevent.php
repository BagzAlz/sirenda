<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Myevent extends CI_Controller {

	

	function __construct()
	{
		parent::__construct();	
		$this->load->model('m_myevent','event');
		$this->m_konfig->validasi_session(array("user"));
		date_default_timezone_set("Asia/Jakarta");
	}
	public function kodevoucher($id)
	{
	echo $this->event->kodevoucher($id);
	}
	
	function _template($data)
	{
	$this->load->view('template/main',$data);	
	}
	function CheckClass()
	{
	$this->load->view("DataCekInClass");
	}function CheckMakan()
	{
	$this->load->view("DataCekInMakan");
	}function CheckRegister()
	{
	$this->load->view("DataCekIn");
	}
	function saveRegister($id)
	{
	echo $this->event->saveRegister($id);
	}
	function editRegister()
	{
	$id=$this->input->post("idPeserta");
	$idEvent=$this->input->post("idEvent");
	$urut=$this->input->post("urut");
	echo $this->event->editRegister($id,$idEvent,$urut);
	}
	function addPeserta($id)
	{
	$this->load->view("modalAdd");
	}
	public function index()
	{
	$reg=$this->session->userdata("reg");
	if($reg) { redirect("myevent/register/$reg"); };
	$data['konten']="dataEvent";
	$this->_template($data);
	}
	public function in($id)
	{
	$data['dataEvent']=$id;
	$this->load->view('checkin',$data);	
	}	
	public function makan($id)
	{
	$data['dataEvent']=$id;
	$this->load->view('makan',$data);	
	}
	public function kelas($id)
	{
	$data['dataEvent']=$id;
	$this->load->view('kelas',$data);	
	}
	
	public function create()
	{

	$data['dataForm']=$this->event->dataForm();
	$data['konten']="create";
	$this->_template($data);
	}
	
	public function edit($id)
	{

	$data['dataForm']=$this->event->dataForm();
	$data['E']=$this->event->dataEventID($id);
	$data['konten']="edit";
	$this->_template($data);
	}
	
	public function kalender()
	{

	$data['konten']="kalender";
	$this->_template($data);
	}
	function process()
	{
	/////////////
//	date_default_timezone_set("Asia/Jakarta");
	$type = $_POST['type'];

	if($type == 'new')
	{
		$startdate = $_POST['startdate'].'+'.$_POST['zone'];
		$title = $_POST['title'];
		$insert ="INSERT INTO data_event(`title`, `startdate`, `enddate`, `allDay`) VALUES('$title','$startdate','$startdate','false')";
		$lastid = $this->db->query($insert);
		echo json_encode(array('status'=>'success','eventid'=>$lastid));
	}

	if($type == 'changetitle')
	{
		$eventid = $_POST['eventid'];
		$title = $_POST['title'];
		$update = $this->db->query("UPDATE data_event SET title='$title' where id_event='$eventid'");
		if($update)
			echo json_encode(array('status'=>'success'));
		else
			echo json_encode(array('status'=>'failed'));
	}

	if($type == 'resetdates')
	{
		$title = $_POST['title'];
		$startdate = $_POST['start'];
		$enddate = $_POST['end'];
		$eventid = $_POST['eventid'];
		$update = $this->db->query("UPDATE data_event SET title='$title', startdate = '$startdate', enddate = '$enddate' where id_event='$eventid'");
		if($update)
			echo json_encode(array('status'=>'success'));
		else
			echo json_encode(array('status'=>'failed'));
	}

	if($type == 'remove')
	{
		$eventid = $_POST['eventid'];
		$delete = $this->db->query("DELETE FROM data_event where id_event='$eventid'");
		if($delete)
			echo json_encode(array('status'=>'success'));
		else
			echo json_encode(array('status'=>'failed'));
	}

	if($type == 'fetch')
	{
		$events = array();
		$fetch = $this->db->query("SELECT * FROM data_event where id_admin='".$this->session->userdata('id')."'")->result();
		foreach($fetch as $fetch)
		{
		$e = array();
		$e['id'] = $fetch->id_event;
		$e['title'] = $fetch->title;
		$e['start'] = $fetch->startdate;
		$e['end'] = $fetch->enddate;

		$allday = ($fetch->allDay == "true") ? true : false;
		$e['allDay'] = $allday;

		array_push($events, $e);
		}
		echo json_encode($events);
	}

/////////
	}
	
	//--------------------------->
	function ajax_open()
	{
		$this->load->library("konversi");
		$list = $this->event->get_open();
		$data = array();
		$no = $_POST['start'];
		$no =$no+1;
		$n=1;
		
		foreach ($list as $dataDB) {
		////
		$terdaftar=$this->event->jmlPeserta($dataDB->id_event,"1");
		$dihadiri=$this->event->jmlPeserta($dataDB->id_event,"2");
		
		$batas=substr($dataDB->batas_registrasi,0,10);
		$jamBatas=substr($dataDB->batas_registrasi,11,5);
		
		if($n==1){
		$warna="emerald-bg";
		}elseif($n==2){
		$warna="red-bg";
		}elseif($n==3){
		$warna="blue-bg";
		}elseif($n==4){
		$warna="purple-bg";
		}else{
		$warna="gray-bg";
		}
		if($n==7){ $n=1; };
		$n++;
		if($dataDB->acc==1){ $acc="Ya"; }else{ $acc="Tidak"; }
		if($dataDB->sistem_tiket==1){ $tiket="Ya"; }else{ $tiket="Tidak"; }
			$row = array();
			if($dataDB->acc==1){ $v="Ya"; }else{ $v="Tidak";}
			
			$row[]='<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<div class="btn-group pull-left" style="padding:10px;position:absolute;right:0px">
				
				<a class="fa fa-edit" style="padding:10px;cursor:pointer" href="'.base_url().'myevent/edit/'.$dataDB->id_event.'"> Edit</a> | 
				<a class="fa fa-trash" style="padding:10px;cursor:pointer" onclick="deleted('.$dataDB->id_event.')"> Hapus</a>
			</div>
			<div class="btn-group pull-right" style="padding:10px;position:absolute">
		<!--	<a onclick="widget('.$dataDB->link.''.$dataDB->id_admin.')" class="btn btn-default btn-xs btn-purple">WIDGET</a>-->
			<a href="'.base_url().'myevent/register/'.$dataDB->id_event.'" class="btn btn-default btn-xs btn-primary">DAFTAR HADIR</a>
		<!--	<a target="_blank" href="'.base_url().'on/line/'.$dataDB->link."".$dataDB->id_admin.'" class="btn btn-default btn-xs btn-purple">LINK PENDAFTARAN</a>-->
			<a target="_blank" href="'.base_url().'myevent/in/'.$dataDB->id_event.'" class="btn btn-default btn-xs btn-danger sadow">CEKIN REG</a>
			<a href="javascript:cekinclass('.$dataDB->id_event.')" class="btn btn-default btn-xs btn-purple">CEKIN CLASS</a>
			<a target="_blank" href="'.base_url().'myevent/makan/'.$dataDB->id_event.'" class="btn btn-default btn-xs btn-danger sadow">CEKIN MAKAN</a>
			</div>
					<div class="main-box weather-box">
					<div class="main-box-body clearfix">
					<div class="main-box weather-box-large" style="margin-bottom:0">
					<div class="main-box-body main-box-no-header clearfix">
					
					<div class="current" style="min-height:205px">
					<h5 style="margin-top:25px;font-size:25px"><b>'.strtoupper($dataDB->title).'</b></h5>
										
					
					<div class="size">
					<i class="fa fa-calendar"></i>	<small>Batas registrasi '.$this->tanggal->hariLengkap($batas,"/").' '.$jamBatas.' WIB</small>
					</div>
					<div class="temp-out-wrapper clearfix">
					<p class="sadow editable editable-pre-wrapped editable-click" data-type="textarea" data-pk="1" data-original-title="" data-title="Enter comments" id="comments">'.$dataDB->ket.'</p>
									
					</div>
					</div>
					</div>
					</div>
					<div class="next">
					<ul class="clearfix">
					<li>
					<div class="day">
					QUOTA
					</div>
					<div class="icon" title="Hot" data-toggle="tooltip">
					<i class="wi wi-hot"></i>
					</div>
					<div class="temperature">
					'.$dataDB->quota.'<span class="sign"></span>
					</div>
					</li>
					<li>
					<div class="day">
					FORM
					</div>
					<div class="icon" title="Showers" data-toggle="tooltip">
					<i class="wi wi-day-showers"></i>
					</div>
					<div class="temperature" onclick="tampilForm(`'.$dataDB->id_event.'`,`'.$this->event->namaForm($dataDB->id_event).'`)">
					'.$this->event->namaForm($dataDB->id_form).'<span class="sign"></span>
					</div>
					</li>
					<li>
					<div class="day">
					Verifikasi Peserta
					</div>
					<div class="icon" title="Cloudy" data-toggle="tooltip">
					<i class="wi wi-cloudy-windy"></i>
					</div>
					<div class="temperature">
					'.$v.'<span class="sign"></span>
					</div>
					</li>
					<li>
					
					<div class="day">
					SISTEM TIKET
					</div>
					<div class="icon" title="Thunderstom" data-toggle="tooltip">
					<i class="wi wi-thunderstorm"></i>
					</div>
					<div class="temperature">
					'.$tiket.'<span class="sign"></span>
					</div>
					</li>
					<li>
					<div class="day">
					Dihadiri
					</div>
					<div class="icon" title="Lightning" data-toggle="tooltip">
					<i class="wi wi-night-alt-lightning"></i>
					</div>
					<div class="temperature">
					'.$dihadiri.'<span class="sign"></span>
					</div>
					</li>
					</ul>
					</div>
					</div>
					</div>
					</div>
					</div>
					</div>';
					
			//add html for action
			$rowx= '
			
			<a class="table-link" href="javascript:void()" title="Lihat" onclick="tampil(`'.$dataDB->id_event.'`,`'.$dataDB->id_event.'`)">
			<span class="fa-stack"><i class="fa fa-square fa-stack-2x"></i><i class="fa fa-eye fa-stack-1x fa-inverse"></i>
			</span> </a>
			
			<a class="table-link" href="javascript:void()" title="Edit" onclick="edit('.$dataDB->id_event.')">
			<span class="fa-stack"><i class="fa fa-square fa-stack-2x"></i><i class="fa fa-pencil fa-stack-1x fa-inverse"></i>
			</span> </a>
			
			
			<a class="table-link danger" href="javascript:void()" title="Hapus" onclick="deleted('.$dataDB->id_event.')">
			<span class="fa-stack"><i class="fa fa-square fa-stack-2x"></i><i class="fa fa-trash-o fa-stack-1x fa-inverse"></i>
			</span> </a>';		
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->event->count_file("data_event"),
						"recordsFiltered" =>$this->event->count_filtered('data_event'),
						"data" => $data,
						);
		//output to json format
		echo json_encode($output);

	}
	
	function delete($id)
	{
	echo $this->event->delete($id);
	}
	function save()
	{
	$data=$this->event->save();
	echo json_encode($data);
	}
	function getBarcode($id)
	{
	$data['id']=$id;
	$this->load->view("getBarcode",$data);
	}
	function saveChange($id)
	{
	echo $this->event->saveChange($id);
	}
	function loadinvoice($ket)
	{
	$data['ket']=$ket;
	$this->load->view("invoice",$data);
	}
	
	function editPeserta($id)
	{
	$data["idEvent"]=$id;
	$data["urut"]=$this->input->post("urut");
	$data["idPeserta"]=$this->input->post("idPeserta");
	$this->load->view("formEdit",$data);
	}
	function loadNewinvoice()
	{
	$this->load->view("Newinvoice");
	}
	
	function sessiondate($id)
	{
	$this->session->set_userdata(array("date"=>$id));
	}
	
	function register($id)
	{

	$data['konten']="peserta";
	$this->_template($data);
	}
	function saveket()
	{
	$this->db->where("id_admin",$this->session->userdata("id"));
	$this->db->where("id_peserta",$this->input->post("idPeserta"));
	echo $this->db->update("data_peserta",array("ket"=>$this->input->post("ket")));
	}	
	function saveMakan()
	{
	$this->db->where("id_admin",$this->session->userdata("id"));
	$this->db->where("id_peserta",$this->input->post("idPeserta"));
	echo $this->db->update("data_peserta",array("makan"=>$this->input->post("makan")));
	}
	
	function getKet($id)
	{
	$this->db->where("id_admin",$this->session->userdata("id"));
	$this->db->where("id_peserta",$id);
	$data=$this->db->get("data_peserta")->row();
	$dt=$id."::".$data->ket;
	echo $dt;
	}
	function getMakan($id)
	{
	$this->db->where("id_admin",$this->session->userdata("id"));
	$this->db->where("id_peserta",$id);
	$data=$this->db->get("data_peserta")->row();
	$dt=$id."::".$data->makan;
	echo $dt;
	}
	
	function ajax_peserta()
	{
		$list = $this->event->get_peserta();
		$data = array();
		$no = $_POST['start'];
		$no =$no+1;
		///
		//$id=$this->uri->segment(3); 
	//	$event=$this->event->dataEvent($id);
	//	$jmlKolom=$this->event->jmlKolom($event->id_form); 
		foreach ($list as $dataDB) {
		////
		$isidata=explode(" __v||v__ ",$dataDB->data);
			$row = array();
			$row[] = "<span class='size'>".$no++."</span>";
			$jmlKolom=count($isidata);
			for($i=0;$i<($jmlKolom-1);$i++)
			{
			
			if(count(explode("_@-ahref-@_",$isidata[$i]))>1){
				$isiUpload=str_replace("_@-ahref-@_","",$isidata[$i]);
								
			$isi="<a target='_blank' href='".base_url()."file_upload/form/".$dataDB->id_admin."_".$dataDB->id_event."/".$isiUpload."'>Lihat </a> |<a href='javascript:edit(`".$i."`,`".$dataDB->id_peserta."`)'> Edit </a>";
			
			}else
			{
			$isi="<a href='javascript:edit(`".$i."`,`".$dataDB->id_peserta."`)' style='color:black'>".$isidata[$i]."</a>";
			if($isidata[$i]==""){ $isi="<a href='javascript:edit(`".$i."`,`".$dataDB->id_peserta."`)'>-----------</a>";}
			$isi=$isi;
			}
		
			
			
			$row[] = "<span class='size'>".$isi."</span>";
			
			}
			
			$jmlMakan=count(explode(",",substr($dataDB->makan,1,99999)));
			if($dataDB->makan==""){ $jmlMakan=0; }
			
			if(!$dataDB->ket){ $ket='<a href="javascript:ket(`'.$dataDB->id_peserta.'`)">----------</a>';}else{ 
			$ket='<a href="javascript:ket(`'.$dataDB->id_peserta.'`)">'.$dataDB->ket.'</a>';};
			$row[]=" <a href='javascript:getbarcode(`".$dataDB->kode_registrasi."`)'>  ".$dataDB->kode_registrasi."</a> ";
			$row[] = "<span class='size'>".$ket."</span>";
			$row[] = "<a href='javascript:makan(`".$dataDB->id_peserta."`)'><span class='size'>".$jmlMakan."</span></a>";
			//add html for action
			
			if($dataDB->status=="0")
			{
			$acc='<a class="label label-danger" href="javascript:void()" data-toggle="tooltip" data-placement="top" title="Klik untuk menyetuji" onclick="acc('.$dataDB->id_peserta.')">
			<i class="fa fa-lg fa-minus"></i></a>';
			}elseif($dataDB->status=="1")
			{
			$acc='<a class="label label-info" href="javascript:void()"  data-toggle="tooltip" data-placement="top" title="Klik untuk batal menyetujui" onclick="not('.$dataDB->id_peserta.')">
			<i class="fa fa-lg fa-dot-circle-o"></i> </a>';
			}else
			{
			$acc='<a class="label label-primary" href="javascript:void()" title="Batalkan" onclick="acc('.$dataDB->id_peserta.')">
			<i class="fa fa-check fa-lg"></i> </a>';
			}
			
			$row[] = $acc.'		
					
			<a class="table-link danger" href="javascript:void()" title="Hapus" onclick="deleted('.$dataDB->id_peserta.')">
			<span class="fa-stack"><i class="fa fa-square fa-stack-2x"></i><i class="fa fa-trash-o fa-stack-1x fa-inverse"></i>
			</span> </a>';	

			
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->event->count_file_peserta("data_peserta"),
						"recordsFiltered" =>$this->event->count_filtered_peserta('data_peserta'),
						"data" => $data,
						);
		//output to json format
		echo json_encode($output);
	}
	function deletePeserta($id)
	{
	echo $this->event->deletePeserta($id);
	}
	function acc($id,$event)
	{
	echo $this->event->acc($id,$event);
	}function not($id)
	{
	echo $this->event->not($id);
	}
	function updatedCheckIn($id)
	{
	$this->load->view("UpdatedCheckIn");
	}
	function exportPeserta($id)
	{
	$this->load->library("PHPExcel");
	$this->event->exportPeserta($id);
	}
	
	function download_template($id)
	{
	$this->load->library("PHPExcel");
	$this->event->download_template($id);
	}
	
	function modeEvent($id)
	{
	$iduser=$this->session->userdata("id");
	$this->db->where("id_admin",$iduser);
	$this->db->where("id_event",$id);
	$this->session->set_userdata(array("reg"=>$id));
	return $this->db->update("data_event",array("mode"=>"0"));
	}
	function upload_file($id)
	{
		if($this->input->post("hapus")==1)
		{
		$this->event->deleteAllPeserta($id);
		$iduser=$this->session->userdata("id");
		$this->db->where("id_admin",$iduser);
		$this->db->where("id_event",$id);
		$this->db->delete("data_peserta");
		}
		$data=$this->event->do_upload_file($id);
		$data=explode("-",$data);
               ?><hr>
			   <center><p class="text-green"><b>Selesai di Import</b></p></center>
                <table class="table table-hover table-bordered" >
			       <?php echo "<tr><td>Berhasil di Import</td><td>:</td><td>".$data[0]."</td></tr>"; ?>
					<?php echo "<tr><td>Gagal di Import</td><td>:</td><td>".$data[1]."</td></tr>"; ?>
                </table>
                <?php
    }
}


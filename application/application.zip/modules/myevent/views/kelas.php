<?php
$uri=$this->uri->segment(3);
$class=$this->uri->segment(4);
$id=$this->session->userdata("id");
$con=$this->event->dataEventID($uri);

?>
<!DOCTYPE html>
<html lang="en">

    <head>
 
        <meta charset="utf-8">
        <title>CEKIN|CLASS</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="aplikasir online">
        <meta name="author" content="">
<link href='<?php echo base_url()?>plug/images/depag.png' rel='shortcut icon' type='image/vnd.microsoft.icon'/>
        <!-- CSS -->
        <style>
        .a:hover{color:red};
        .limit{
        background-color:black;color:white;
        }
		
        </style>
        <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=PT+Sans:400,700'>
        <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Oleo+Script:400,700'>
        <link rel="stylesheet" href="<?php echo base_url()?>plug/register/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo base_url()?>plug/register/css/style.css">

		<script type="text/javascript" src="<?php echo base_url()?>plug/paralax/js/modernizr.custom.28468.js"></script>

<style>
#mapDiv {
    width:220px;
    height:220px;
   
	border-radius:20px;
    margin:auto;
    -moz-box-shadow:5px 5px 10px #000;
    -webkit-box-shadow:5px 5px 10px #000;
}
.sadow{
text-shadow: 1px 1px 1px #999999;
}.sadow05{
text-shadow: 0.5px 0.5px 0.5px #999999;
}
</style>
		

    </head>

    <body>

        <div class="header pattern bg">
            <div class="container">
                <div class="row" >
                    <div class="logo red">
                 <!--    <img class="img" src="<?php echo base_url()?>plug/img/web.png" width="70px" style="position:absolute;margin-left:-130px;margin-top:5px">   -->
					 <h1 style='margin-left:-25px'><a href=""> <span class="black" style="font-size:22px">CHECK IN CLASS ROOM</span></a>
                      </h1>
	  <span id="text" style="font-size:18px;color:maroon;position:absolute;margin-top:-20px;margin-left:15px">
	
						
                    </div>
                
                </div>
            </div>
        </div>

<?php
if(!isset($con->title)){ echo "<center> <h1 style='color:white'>  Maaf! Event Tidak Ditemukan!	  </h1></center>";	}else{ 

?>

<table  align="center" width="90%">
<tr>
<td align="left" width="500px">  
<br>
		   
                <div class="bg register" style="max-width:500px">
                    <form action="javascript:save()" method="post" id="formRegistrasi" enctype="multipart/form-data">
                        <h2> <span class="red"><strong><?php echo $class=$this->uri->segment(4); ?></strong></span><br>
						<small>Enter Registration ID Number  </small>
						</h2>
                        
						<input type="text" name="ID" id="ID" style='border:2px solid red'>
	                           
                       <div id="inforeg1"></div>
                     Use Barcode Scaner or Press Enter
					</form>	
                   
                </div>
			<center>
<?php
$date=$this->session->userdata("date");
		if(!$date){
		$date=date('Y-m-d');
		}
		?>
<span id="updates">
<h2 style='color:white' class="sadow05"><?php echo $this->tanggal->hariLengkap($date,"/"); ?></h2>				
</span>
</center>
</td>
<td  align="center">
	
	   
        <div id="text">
          
		    <div style="margin-top:20px"  >
			<div id="hasilCek" ></div>
            </div>
			
        </div>
	
</td>
</tr>
</table>
	
	<?php } ?>
	
        <!-- Javascript -->
        <script src="<?php echo base_url()?>plug/js/jquery-2.2.1.min.js"></script>
      

<script>
 

$("#modalcek").hide();
$(document).ready(function(){
setfocus();
$(".login").hide();
   $(".registerbutton").click(function(){
	$("#modalcek").modal("show");
}); 

});

function setfocus()
{
$("#ID").val("");
 document.getElementById("ID").focus();
}

</script>

</body>
</html>







  
  
  
<style type="text/css">
#text {
	text-align:center;

	-webkit-tranform:translateZ(0);
	-webkit-transition-duration:0.05s;
	-moz-tranform:translateZ(0);
	color:#f3f3f3;
	text-shadow:0 0 1px rgba(0,0,0,.2);
}
.sadow{
text-shadow: 0 1px 0 #ccc, 
               0 2px 0 #c9c9c9,
               0 3px 0 #bbb,
               0 4px 0 #b9b9b9,
               0 5px 0 #aaa,
               0 6px 1px rgba(0,0,0,.1),
               0 0 5px rgba(0,0,0,.1),
               0 1px 3px rgba(0,0,0,.3),
               0 3px 5px rgba(0,0,0,.2),
               0 5px 10px rgba(0,0,0,.25),
               0 10px 10px rgba(0,0,0,.2),
               0 20px 20px rgba(0,0,0,.15);
font-size:300%;
}
.val{
border-radius:25px;
padding:20px 20px 20px 20px;
}
</style>
<script src="<?php echo base_url('plug/jqueryform/jquery.form.js');?>"></script>
<script>
function updated()
    {
      var  url = "<?php echo base_url();?>myevent/updatedCheckIn/<?php echo $this->uri->segment(3);?>";
       // ajax adding data to database
          $.ajax({
            url : url,
            type: "POST",
             success: function(data)
            {
           	 $('#update').html(data);			 
            }
        });
    }
	
</script>

<script>
function save()
    {
	var ID=$("#ID").val();
        $('#hasilCek').html('<img width="200px" src="<?php echo base_url()?>plug/img/progres.gif" /> <b>System Checking ... </b>');
      var  url = "<?php echo base_url();?>myevent/CheckClass/<?php echo $this->uri->segment(3);?>/<?php echo $class; ?>";
       // ajax adding data to database
          $.ajax({
            url : url,
            type: "POST",
			data:"ID="+ID,
             success: function(data)
            {
               //if success close modal and reload ajax table
			  $('#formRegistrasi')[0].reset();
			  setfocus();
			 $('#hasilCek').html(data);			
			updated();			 
			 
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
              alert('Mohon maaf kami sedang melakukan perbaikan\nTerimakasih atas pengertiannya.');
            }
        });
    }
	
</script>













  <!-- Bootstrap modal -->
  <div class="modal fade" id="widget" role="dialog" style="max-width:415px">
   <div class="modal-dialog">
      <div class="modal-body" style="margin-top:10px">
	  Silahkan Pilih Tanggal :
<?php
$id=$this->uri->segment(3);
$date=$this->db->query("SELECT DISTINCT(SUBSTR(tgl,1,10)) AS tgl FROM data_peserta where id_event='".$id."' order by tgl asc")->result();
$dat=$this->db->query("SELECT SUBSTR(startdate,1,10) as startdate,SUBSTR(enddate,1,10) as enddate FROM data_event where id_event='".$id."'")->row();
$selisih=$this->tanggal->selisih($dat->startdate,$dat->enddate);
$dbase[]=array();
$sd=$this->session->userdata("date");

for($i=0;$i<=$selisih;$i++)
		{
		$tgl = mktime(0, 0, 0, SUBSTR($dat->enddate,5,2), SUBSTR($dat->enddate,8,2)-$i, SUBSTR($dat->enddate,0,4));
		$tglE=date("Y-m-d", $tgl);
		$tgl=date("Y-m-d", $tgl);
$dbase[$tglE]=$this->tanggal->hariLengkap($tgl,"/");
}


$array=$dbase;
echo form_dropdown("date",$array,$sd,'class="form-control input-sm" id="date" onchange="date()"');
 ?>
</div>

      </div><!-- /.modal -->
    </div><!-- /.modal -->
  <!-- End Bootstrap modal -->
<script src="<?php echo base_url();?>plug/register/bootstrap/js/bootstrap.min.js"></script>
<script>
<?php
if(!$sd)  {	?>
 $(document).ready(function(){
	$("#widget").modal("show");
 });
<?php } ?>
 
 function date()
    {
      var date=$("#date").val();
        // ajax delete data to database
          $.ajax({
            url : "<?php echo base_url();?>myevent/sessiondate/"+date,
            type: "POST",
            data: "JSON",
            success: function(data)
            {
               //if success reload ajax table
              $("#widget").modal("hide");
			  updated();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error adding / update data');
            }
        });
         
     
    } 
	
</script>
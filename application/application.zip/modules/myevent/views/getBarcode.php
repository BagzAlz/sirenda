<script type="text/javascript" src="<?php echo base_url();?>plug/js/printArea.js"></script>
 <script type="text/javascript">
      function generateBarcode(){ 
	        var settings = {
			output:"bmp",
          bgColor: "#f9f9f9",
       //   color: $("#color").val(),
          barWidth: 3,
         // barHeight: $("#barHeight").val(),
        //  moduleSize: $("#moduleSize").val(),
         //posX:12,
        //  posY: $("#posY").val(),
        //  addQuietZone: $("#quietZoneSize").val()
        };

          $("#barcodeTarget").html("").show().barcode("<?php echo $id; ?>", "ean13",settings);
          }
          
		   
   $(function(){   generateBarcode();     });
  
  </script>
<!----------------------------------->
<div class="col-lg-12" style='color:white'>
<center>
<br><br><br>
<br><br><br>
<br><br><br>
<b>DOWNLOAD BARCODE</b> <br><b>Klik Kanan</b> kemudian <b>Save image As</b><br><br>
 <div id="barcodeTarget" class="barcodeTarget" ></div>
 <button class='print btn btn-primary'>Print</button>
</center>
</div>
<script>
        (function($) {
            // fungsi dijalankan setelah seluruh dokumen ditampilkan
            $(document).ready(function(e) {
                 
                // aksi ketika tombol cetak ditekan
                $(".print").bind("click", function(event) {
                    // cetak data pada area <div id="#data-mahasiswa"></div>
                    $('#barcodeTarget').printArea();
                });
            });
        }) (jQuery);
    </script>

				<!----------------------------------->
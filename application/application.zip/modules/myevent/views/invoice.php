<?php
$data=$this->db->query("select MAX(id_invoice) as max from data_invoice where id_admin='".$this->session->userdata("id")."' ")->row();
if($ket=="saldo")
{
$data='<hr>
<div class="alert alert-info black">
<font color="green"><i class="fa fa-check-square"></i></font> Selamat Event berhasil di buat dan Event ini telah dibayar dengan saldo akun anda.
</div>';
}elseif($ket=="voucher")
{
$data='<hr>
<div class="alert alert-info black">
<font color="green"><i class="fa fa-check-square"></i></font> Selamat Event berhasil di buat dan  Event ini telah dibayar dengan kode voucher gratis.
</div>';
}else
{
$data='<hr>
<div class="alert alert-info black">
<font color="green"><i class="fa fa-check-square"></i></font> Event berhasil di buat dan kami telah menerbitkan invoice silahkan cek 
 <a href="'.base_url().'payment/invoice/'.$data->max.'" target="new">invoice</a>
</div>';
}
echo $data;
<center>
<?php
$date=$this->session->userdata("date");
		if(!$date){
		$date=date('Y-m-d');
		}
		?>
<span id="updates">
<h2 style='color:white' class="sadow05"><?php echo $this->tanggal->hariLengkap($date,"/"); ?></h2>				
</span>
</center>
	


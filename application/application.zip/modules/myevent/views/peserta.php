<?php $con=new umum(); 
$id=$this->uri->segment(3); 
$event=$this->event->dataEvent($id);

if(!isset($event)){ redirect('myevent'); }; 

$jmlKolom=$this->event->jmlKolom($event->id_form); 
$order="";
for($i=1;$i<=($jmlKolom+4);$i++)
{
$order.=$i.",";
$order=$order;
}


$dataForm=$this->event->getDataForm($event->id_form); ?> 
<!--<script src="<?php echo base_url()?>plug/js/jquery-2.2.1.min.js"></script>
<script src="<?php echo base_url();?>plug/jqueryform/jquery.form.js"></script>-->

<div class="row" id="user-profile">
<div class="col-lg-12 col-md-12 col-sm-12" >
<div class="main-box clearfix">
<header class="main-box-header clearfix"><center>
<h2><b>Peserta <?php echo $con->namaEvent($id);?> </b></h2></center>
</header>
<div class="main-box-body clearfix">
<a style="margin-top:-10px" class="btn btn-primary  pull-right" href="javascript:reload_table()"><i class="fa fa-refresh"></i> Refresh</a>
<div class="pull-right" style='margin-top:-8px'>
<?php

$date=$this->db->query("SELECT DISTINCT(SUBSTR(tgl,1,10)) AS tgl FROM data_peserta where id_event='".$id."' order by tgl asc")->result();
$dat=$this->db->query("SELECT SUBSTR(startdate,1,10) as startdate,SUBSTR(enddate,1,10) as enddate FROM data_event where id_event='".$id."'")->row();
$selisih=$this->tanggal->selisih($dat->startdate,$dat->enddate);
$dbase[]=array();
$sd=$this->session->userdata("date");
if(!$sd)
{
$this->session->set_userdata(array("date"=>$dat->enddate));
}

for($i=0;$i<=$selisih;$i++)
		{
		$tgl = mktime(0, 0, 0, SUBSTR($dat->enddate,5,2), SUBSTR($dat->enddate,8,2)-$i, SUBSTR($dat->enddate,0,4));
		$tglE=date("Y-m-d", $tgl);
		$tgl=date("Y-m-d", $tgl);
$dbase[$tglE]=$this->tanggal->hariLengkap($tgl,"/");
}


$array=$dbase;
echo form_dropdown("date",$array,$sd,'class="form-control input-sm" id="date" onchange="date()"');
 ?>
</div>



<a style="margin-top:-10px" class="btn btn-primary" href="<?php echo base_url();?>myEvent/exportPeserta/<?php echo $id;?>"><i class="fa fa-file-excel-o"></i> Export </a>
<a style="margin-top:-10px" class="btn btn-primary" href="javascript:import_file(<?php echo $id; ?>)"><i class="fa fa-cloud-upload"></i> Import </a>
<a style="margin-top:-10px" class="btn btn-primary " href="javascript:add(<?php echo $id;?>)"><i class="fa fa-plus-circle"></i> Add Peserta</a>
<?php
$dbm=$this->db->query("select mode from data_event where id_event='".$id."'")->row();
$dbm=isset($dbm->mode)?($dbm->mode):1;
if($dbm==1)
{?>
<a style="margin-top:-10px" class="btn btn-danger " href="javascript:mode(<?php echo $id;?>)">Mode Operator</a>
<?php } ?>
<br>

<span id="dataTable">
<b><center>
</center></b>
<table id='table' class="tabel black table-striped table-bordered table-hover dataTable">
		  	<thead>			
				<th class='thead' axis="string" width='15px'>No</th>
				<?php foreach($dataForm as $val){
				echo "<th  axis='string' style='padding-left:5px'>".$val->nama_form."</th>";
				};?>
				<th  class='thead'>ID Registrasi</th>
				<th  class='thead'>Class</th>
				<th  class='thead'>Makan</th>
				<th  class='thead' width="50px">&nbsp;</th>
			</thead>
</table>
</span>
<hr>
<div>
Keterangan symbol :
<p style='margin-top:-1px'><div class="label label-danger" ><i class="fa fa-lg fa-minus"></i></div> <b><font color="black">Belum disetujui</font></b> ( perlu persetujuan anda , silahkan klik pada symbol untuk menyetujui pendaftar )</p>
<p style='margin-top:-1px'><div class="label label-info"><i class="fa fa-lg fa-dot-circle-o"></i></div> <b><font color="black">Terdaftar</font></b> (Register ini berhak melakukan Check-In pada saat event dimulai)</p>
<p style='margin-top:-1px'><div class="label label-primary" ><i class="fa fa-lg fa-check"></i></div> <b><font color="black"> Check In</font></b> (Pendaftar telah melakukan proses Check-in)</p>
<p style="margin-top:-1px"><div class="label label-primary"><i class="fa fa-lg fa-trash"></i></div> <b><font color="black"> Hapus</font> </b> ( untuk menghapus data register klik pada symbol ) </p><br>
<p style='margin-top:-1px'>Untuk mendownload Barkode register silahkan klik pada nomor <b>"kode Register"</b></p>
</div>
</div>
</div>
</div>




  <link href="<?php echo base_url();?>/plug/datatables/css/dataTables.bootstrap.css" rel="stylesheet">
  <script src="<?php echo base_url()?>plug/datatables/js/jquery.dataTables.min.js"></script>
  <script src="<?php echo base_url()?>plug/datatables/js/dataTables.bootstrap.js"></script>	
  <script>
  $(".tabel-inputan").hide();
  $(".pratampil").hide();
  function addForm(){
  $(".tabel-inputan").fadeIn(1000);
  $("#dataTable").fadeOut(1000);
  $(".crt").hide();
  }
  </script>

  <script type="text/javascript">
      var save_method; //for save method string
    var table;
    $(document).ready(function() {
	generateBarcode("123456789876"); 
      table = $('#table').DataTable({ 
        
        "processing": true, //Feature control the processing indicator.
        "serverSide": true, //Feature control DataTables' server-side processing mode.
        
        // Load data for the table's content from an Ajax source
        "ajax": {
            "url": "<?php echo site_url('myevent/ajax_peserta/'.$this->uri->segment(3).'')?>",
            "type": "POST"
        },

        //Set column definition initialisation properties.
        "columnDefs": [
        { 
          "targets": [ <?php echo $order ?>], //last column
          "orderable": false, //set not orderable
        },
        ],

      });
    });

    function reload_table()
    {
      table.ajax.reload(null,false); //reload datatable ajax 
    }
	
	 function date()
    {
      var date=$("#date").val();
        // ajax delete data to database
          $.ajax({
            url : "<?php echo base_url();?>myevent/sessiondate/"+date,
            type: "POST",
            data: "JSON",
            success: function(data)
            {
               //if success reload ajax table
               reload_table();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error adding / update data');
            }
        });
         
     
    } 
	
	function deleted(id)
    {
      if(confirm('Are you sure delete this data?'))
      {
        // ajax delete data to database
          $.ajax({
            url : "<?php echo base_url();?>myevent/deletePeserta/"+id,
            type: "POST",
            data: "JSON",
            success: function(data)
            {
               //if success reload ajax table
               reload_table();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error adding / update data');
            }
        });
         
      }
    }	 
	
	
	function not(id)
    {
     
        // ajax delete data to database
          $.ajax({
            url : "<?php echo base_url();?>myevent/not/"+id,
            type: "POST",
            data: "JSON",
            success: function(data)
            {
               //if success reload ajax table
               reload_table();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error adding / update data');
            }
        });
         
      
    }
	
	function acc(id)
    {
     
        // ajax delete data to database
          $.ajax({
            url : "<?php echo base_url();?>myevent/acc/"+id+"/<?php echo $this->uri->segment(3);?>",
            type: "POST",
            data: "JSON",
            success: function(data)
            {
               //if success reload ajax table
			   if(data==3){ alert('Quota penuh!'); }
               reload_table();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error adding / update data');
            }
        });
         
      
    }
	
	
	
	function add(id)
	{
	// ajax delete data to database
          $.ajax({
            url : "<?php echo base_url();?>myevent/addPeserta/"+id,
            type: "POST",
            data: "JSON",
            success: function(data)
            {
               //if success reload ajax table
              $("#modal_form").modal("show");
              $(".bodyx").html(data);
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error adding / update data');
            }
        });
	
	}
	
	function mode(id)
	{
	// ajax delete data to database
          $.ajax({
            url : "<?php echo base_url();?>myevent/modeEvent/"+id,
            type: "POST",
            data: "JSON",
            success: function(data)
            {
              window.location.href="<?php echo base_url();?>myevent/register/"+id;
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error adding / update data');
            }
        });
	
	}
	
	
	function edit(urut,idPeserta)
	{
	// ajax delete data to database
          $.ajax({
            url : "<?php echo base_url();?>myevent/editPeserta/<?php echo $this->uri->segment(3);?>",
            type: "POST",
            data: "idPeserta="+idPeserta+"&urut="+urut,
            success: function(data)
            {
               //if success reload ajax table
              $("#modal_edit").modal("show");
              $(".modal_edit").html(data);
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error adding / update data');
            }
        });
	
	}
	
	function getbarcode(id)
	{
	// ajax delete data to database
          $.ajax({
            url : "<?php echo base_url();?>myevent/getBarcode/"+id,
            type: "POST",
            data: "JSON",
            success: function(data)
            {
               //if success reload ajax table
              $("#barcode").modal("show");
              $(".modal-barcode").html(data);
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error adding / update data');
            }
        });
	}	
	
	function barcodeHide()
	{
	
              $("#barcode").modal("hide");
             
	}	
	
	

</script>

<script type="text/javascript" src="<?php echo base_url();?>plug/js/barcode.js"></script>
 <!-- Bootstrap modal -->
  <div class="modal fade" id="barcode" role="dialog" onclick="barcodeHide()">
 <div class="modal-dialog">
      <div class="modal-barcode">
      
    </div><!-- /.modal -->
    </div><!-- /.modal -->
    </div><!-- /.modal -->
  <!-- End Bootstrap modal -->
  <script>
  function makan(id)
	{
    // ajax delete data to database
          $.ajax({
            url : "<?php echo base_url();?>myevent/getMakan/"+id,
            type: "POST",
            data: "JSON",
            success: function(data)
            {
			var dt=data.split("::");
            var idp=$("#idPeserta").val(dt[0]);
            var vket=$(".makan").val(dt[1]);
            $("#makan").modal("show");
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error adding / update data');
            }
        });
	}	  
	function ket(id)
	{
    // ajax delete data to database
          $.ajax({
            url : "<?php echo base_url();?>myevent/getKet/"+id,
            type: "POST",
            data: "JSON",
            success: function(data)
            {
			var dt=data.split("::");
            var idp=$("#idPeserta").val(dt[0]);
            var vket=$(".vket").val(dt[1]);
            $("#ket").modal("show");
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error adding / update data');
            }
        });
	}	
	
	function saveMakan()
	{
	var idp=$("#idPeserta").val();
	var makan=$(".makan").val();
	// ajax delete data to database
          $.ajax({
            url : "<?php echo base_url();?>myevent/saveMakan",
            type: "POST",
            data: "idPeserta="+idp+"&makan="+makan,
            success: function(data)
            {
              reload_table()
              $("#makan").modal("hide");
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error adding / update data');
            }
        });
	}	
	
	function saveket()
	{
	var idp=$("#idPeserta").val();
	var vket=$(".vket").val();
	// ajax delete data to database
          $.ajax({
            url : "<?php echo base_url();?>myevent/saveket",
            type: "POST",
            data: "idPeserta="+idp+"&ket="+vket,
            success: function(data)
            {
              reload_table()
              $("#ket").modal("hide");
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error adding / update data');
            }
        });
	}
  </script>
  
 <!-- Bootstrap modal -->
  <div class="modal fade" id="makan" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title black"><b>Jam Makan</b></h4>
      </div>
      <div class="modal-body form">
	  <input type="hidden" id="idPeserta">
        <input type="text" class="form-control makan"></input><br>
		<button class='btn btn-primary' onclick="saveMakan()">simpan</button>
      </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    </div><!-- /.modal -->
  <!-- End Bootstrap modal -->  
  
  <!-- Bootstrap modal -->
  <div class="modal fade" id="ket" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title black"><b>Class</b></h4>
      </div>
      <div class="modal-body form">
	  <input type="hidden" id="idPeserta">
        <input type="text" class="form-control vket"></input><br>
		<button class='btn btn-primary' onclick="saveket()">simpan</button>
      </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    </div><!-- /.modal -->
  <!-- End Bootstrap modal -->  
  
  
  


  
  <script type="text/javascript" src="<?php echo base_url();?>plug/js/barcode.js"></script>
	<link rel="stylesheet" href="<?php echo base_url();?>plug/css/styleTiket.css" type="text/css" media="all" />
	<link href='http://fonts.googleapis.com/css?family=Questrial|Droid+Sans|Alice' rel='stylesheet' type='text/css'>
 <script type="text/javascript">
      function generateBarcode(id){ 
	        var settings = {
			output:"bmp",
          bgColor: "#f9f9f9",
       //   color: $("#color").val(),
          barWidth: 2,
         // barHeight: $("#barHeight").val(),
        //  moduleSize: $("#moduleSize").val(),
         //posX:12,
        //  posY: $("#posY").val(),
        //  addQuietZone: $("#quietZoneSize").val()
        };

          $("#barcodeTarget").html("").show().barcode(id, "code128",settings);
          } 
  
    </script>
	
	
	
	
	
	
	
<script>	
function import_file(id)
    {
	
	  $('#modal_form_import').modal('show'); // show bootstrap modal

    }
</script>	
	
	
	
	
	 <!-- Bootstrap modal -->
  <div class="modal fade" id="modal_edit" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title-edit black"><b>Edit</b></h4>
      </div>
      <div class="modal_edit form">
        
          
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
	</div>
  <!-- End Bootstrap modal -->	
	
	
	
	
	 <!-- Bootstrap modal -->
  <div class="modal fade" id="modal_form" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title black"><b>Add Data Peserta</b></h4>
      </div>
      <div class="modal-body bodyx form">
        
          
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
	</div>
  <!-- End Bootstrap modal -->
	

	<!-- Bootstrap modal -->
  <div class="modal fade" id="modal_form_import" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
         <h4 class="modal-title black"><b>Import Data Peserta</b></h4>
      </div>
      <div class="modal-body form">
       
		<script src="<?php echo base_url();?>assets/jqueryform/jquery.form.js"></script>

<section class="content">
  <div class="row">
    <div class="col-lg-12">
      <!-- general form elements -->
      <div class="box box-primary">
        <div class="box-header">
          <h3 class="box-title">Silahkan <a href='<?php echo base_url();?>myevent/download_template/<?php echo $this->uri->segment(3);?>'>download template</a> sebelum upload.</h3>
        </div><!-- /.box-header -->
          <div class="box-body">                      
            <form role="form" name="uploadfilexl" id="uploadfilexl" 
                  action="javascript:simpanfile();" method="post" enctype="multipart/form-data">
                <div class="form-group">
                  <input id="userfile" required name="userfile" type="file">
                </div>
				    <div class="form-group">
                    <label>
                      <input type="checkbox" name='hapus' value='1' class="flat-red" />
                       Hapus semua data peserta sebelumnya
                    </label>
                  </div>
				
				
                <button type="submit" onclick="javascript:simpanfile();" class="btn btn-primary">
                    <span class="glyphicon glyphicon-plus"></span>&nbsp;Upload
                </button>
                <div class="form-group">
                    <div class="hasil"></div>
                </div>
            </form>
          </div><!-- /.box-body -->
      </div><!-- /.box -->
    </div>
  </div>   <!-- /.row -->
</section><!-- /.content -->

          </div>
          <div class="modal-footer">
		   <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
              
          </div>
        </div><!-- /.modal-content -->
      </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
  <!-- End Bootstrap modal -->
<script src="http://aplikasir.com/assets/jqueryform/jquery.form.js"></script>
  <script type="text/javascript">
function simpanfile(){
    var userfile=$('#userfile').val();
    
    $('#uploadfilexl').ajaxForm({
     url:'<?php echo base_url();?>myevent/upload_file/<?php echo $this->uri->segment(3);?>',
     type: 'post',
     data:{"userfile":userfile},
     beforeSend: function() {
        var percentVal = 'Mengupload 0%';
        $('.msg').html(percentVal);
     },
     uploadProgress: function(event, position, total, percentComplete) {
        var percentVal = 'Mengupload ' + percentComplete + '%';
        $('.msg').html(percentVal);
     },
     beforeSubmit: function() {
      $('.hasil').html('<img src="<?php echo base_url();?>plug/img/loader.gif" /> Silahkan Tunggu ... ');
     },
     complete: function(xhr) {
        $('.msg').html('Import file selesai!');
		 reload_table();
     }, 
     success: function(resp) {
        $('.hasil').html(resp);
     },
    });     
};
</script>    	


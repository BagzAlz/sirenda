<form action="#" id="form" class="form-horizontal" enctype="multipart/form-data">
<div class="form-body">
          <input type="hidden" value="" name="id"/> 
		  <!---------------------------------------------------------------->
		  <?php
	$event=$this->event->dataEventID($id=$this->uri->segment(3));
	$this->db->order_by("id_formulir","asc");
	$this->db->where("id_admin",$this->session->userdata("id"));
	$this->db->where("id_data_form",$event->id_form);
	$db=$this->db->get("tm_formulir")->result();
	
	$data="";
	foreach($db as $db)
	{
	if($db->required=="ya"){ $required="required";}else{ $required="";};
	$label=str_replace(" ","_",$db->nama_form);
	if($db->type_form=="2"){
	$data.='	
		 <div class="form-group black">
        	  <label  class="black control-label col-md-3" for="'.$label.'"><b>'.$db->nama_form.'</b></label>
              <div class="col-md-8">
                <textarea name="'.$label.'" class="form-control" '.$required.'></textarea>
              </div>
            </div>';
	}
	
	
	
	
	
	
	elseif($db->type_form=="3"){
	$val="";
	$araypil=$db->pilihan;
	$data3=explode(",",$araypil);
	
	
	$data.='<div class="form-group black" style="">
		<label class="control-label black col-md-3" for="'.$label.'"><b>'.$db->nama_form.'</b></label>
		<div class="col-md-8">';
	
	
	foreach($data3 as $op)
	{
	$val[str_replace(" ","_",$op)]=$op;
	}
	$array=$val;
	$data.=form_dropdown($label,$array,"", 'class="form-control" id="'.$label.'" '.$required.'');
	$data.='</div>';
	$data.='</div>';
	
	}
	
	
	
	elseif($db->type_form=="4"){
	$val="";
	$araypil=$db->pilihan;
	$data4=explode(",",$araypil);
	
		
	$data.='	<div class="form-group">
					<label class="black control-label col-md-3" for="'.$label.'"><b>'.$db->nama_form.'</b></label>';
	foreach($data4 as $op)
	{
	$data.='<div class="checkbox-nice checkbox-inline " >
		<input type="checkbox" id="cek'.str_replace(" ","_",$op).'" name="'.str_replace(" ","_",$op).'"/>
		<label class="black" for="cek'.str_replace(" ","_",$op).'">
		'.$op.'
		</label>
		</div>';
	}	
		
		
		
	$data.=' </div>';
		
	}
	
	
	elseif($db->type_form=="7"){
	$val="";
	$araypil=$db->pilihan;
	$data7=explode(",",$araypil);
	
		
	$data.='<div class="form-group">
					<label class="black control-label col-md-3" for="'.$label.'"><b>'.$db->nama_form.'</b></label>';
		
	foreach($data7 as $op)
	{
	$data.='<div class=" checkbox-inline" >
		<input type="radio" id="ra'.str_replace(" ","_",$op).'" name="'.str_replace(" ","_",$db->nama_form).'"/>
		<label class="black" for="ra'.str_replace(" ","_",$op).'">
		'.$op.'
		</label>
		</div>';
	}	
		
		
		
	$data.='
	</div>';
		
	}elseif($db->type_form=="5"){
		$data.='	
		<div class="form-group black" style="">
		<label class="control-label black col-md-3" for="'.$label.'"><b>'.$db->nama_form.'</b></label>
		<div class="col-md-8">
		<input type="file" name="'.$label.'" class="form-control" id="'.$label.'" '.$required.'>
		</div></div>';
		
	}elseif($db->type_form=="6"){
		$data.='
		<div class="form-group black">
		<label class="control-label black col-md-3" for="datesingle"><b>'.$db->nama_form.'</b></label>
		<div class="input-group col-md-4">
		<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
			<input type="text" name="'.$label.'" class="form-control" id="datesingle" '.$required.'>
		</div>
	
		</div>
		';
	}else{
	$data.='	
		<div class="form-group black" style="">
		<label class="control-label black  col-md-3" for="'.$label.'"><b>'.$db->nama_form.'</b></label>
		<div class="col-md-8">
		<input type="text" name="'.$label.'" class="form-control" id="'.$label.'" '.$required.'>
		</div></div>';
	
	}
	}

	$data.='</div></div>
          <div class="modal-footer"> <span id="inforeg1"></span>
            <button class="btn btn-primary pull-right" onclick="javascript:save()" type="submit">SIMPAN</button>
            <button type="button" class="btn btn-danger pull-left" data-dismiss="modal">Cancel</button>
          </div>';
	echo $data;
	?>
		  <!---------------------------------------------------------------->
          
            
        </form>
		
 <script type="text/javascript">
		
				$('#datesingle').daterangepicker({
			"singleDatePicker": true,
			locale: {
					format: 'DD/MM/YYYY'
				}
				});
	 </script>
	 
	 
	 
<script src="<?php echo base_url('plug/jqueryform/jquery.form.js');?>"></script>
<script>
function save()
    {
       $('#inforeg1').html("<img src='<?php echo base_url();?>plug/img/load.gif'> <font color='#999999'>Please wait...</font>");
      var  url = "<?php echo base_url();?>myevent/saveRegister/<?php echo $id;?>";
       // ajax adding data to database
          $('#form').ajaxForm({
            url : url,
            type: "POST",
            data: $('#form').serialize(),
            dataType: "JSON",
            success: function(data)
            {
               //if success close modal and reload ajax table
			  $('#form')[0].reset();
			  if(data=="3") {
					alert("Quota peserta habis!");
					$('#inforeg1').html("");
							}else
							{
							reload_table()
							 $("#modal_form").modal("hide");
							}
							
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
              alert('Mohon maaf kami sedang melakukan perbaikan\nTerimakasih atas pengertiannya.');
            }
        });
    }
	
</script>
<?php
if($event->status==0){ 
echo "<script>alert('Event ini belum dibayar, Mohon segera melakukan pembayaran.')</script>";
echo '<script> $("select").prop("disabled", true); </script>';
echo '<script> $("textarea").prop("disabled", true); </script>';
echo '<script> $("input").prop("disabled", true); </script>';
echo '<script> $("option").prop("disabled", true); </script>';
echo '<script> $("button").prop("disabled", true); </script>';
};
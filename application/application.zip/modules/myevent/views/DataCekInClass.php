
<?php
$idadmin=$this->session->userdata("id");
$id=$this->input->post("ID");

$this->db->where("id_admin",$idadmin);
$this->db->where("id_event",$this->uri->segment(3));
$this->db->where("kode_registrasi",$id);
$cek=$this->db->get("data_peserta");
if($cek->num_rows())
{
			$data=$cek->row();
			$isidata=explode(" __v||v__ ",$data->data);
			$row = array();
			$isi="<b>DATA DETAIL REGISTER</b><br> ";
			$jmlKolom=count($isidata);
			for($i=0;$i<($jmlKolom-1);$i++)
			{
			
			if(count(explode("_@-ahref-@_",$isidata[$i]))>1){
				$isiUpload=str_replace("_@-ahref-@_","",$isidata[$i]);
								
		//	$isi="<a target='_blank' href='".base_url()."file_upload/form/".$dataDB->id_admin."_".$dataDB->id_event."/".$isiUpload."'>click to view</a>";
			
			}else
			{
			$isi.=$isidata[$i]." | ";
			}
			
			}
			$isi=substr($isi,0,-2);



		/*------------------------*/
		$date=$this->session->userdata("date");
	$this->db->where("id_admin",$idadmin);
	$this->db->where("id_event",$u=$this->uri->segment(3));
		if($date){
		$this->db->where("substr(tgl,1,10)",$date);
		}else
		{
		$this->db->where("substr(tgl,1,10)",$this->event->tglAwal($u));
		$date=date('Y-m-d');
		}
	$this->db->where("kode_registrasi",$id);
	$this->db->order_by("tgl","DESC");
	$cek=$this->db->get("data_peserta")->num_rows();		
			
			
	if($data->status=="0")
	{
			echo "<span class='sadow'><img width='100px' src='".base_url()."plug/img/warning.png'> <br>BELUM TERVERIFIKASI</span>";
	}else
	{
		if($cek>0)
		{
		$this->event->updateStatusClassPeserta($id,$class=$this->uri->segment(4));
			echo "<div class='span8'><img width='100px' src='".base_url()."plug/img/cek.png'><br> <span class='sadow'>WELCOME IN CLASS $class</span> 
			<br><br><font size='5px'> ".$isi."</font> <br>
		<center><hr style='width:30%'>
			Class Room ".$data->ket."
			</div>";
		}else
		{
		echo "<span class='sadow'><img width='100px' src='".base_url()."plug/img/warning.png'> <br>BELUM REGISTRASI</span>";
		}
			
		
	}
}else
{
echo "<span class='sadow'><img width='100px' src='".base_url()."plug/img/warning.png'> <br><br>".$id." <br> <br> TIDAK TERDAFTAR</span>";
}
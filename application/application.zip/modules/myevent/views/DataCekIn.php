<?php
$idadmin=$this->session->userdata("id");
$id=$this->input->post("ID");
$tgl=date('Y-m-d');
$date=$this->session->userdata("date");
$this->db->where("id_admin",$idadmin);
$this->db->where("id_event",$u=$this->uri->segment(3));
	/*	if($date){
		$this->db->where("substr(tgl,1,10)",$date);
		}else
		{
		$this->db->where("substr(tgl,1,10)",$this->event->tglAwal($u));
		}*/
$this->db->where("kode_registrasi",$id);
$this->db->order_by("tgl","DESC");
$cek=$this->db->get("data_peserta");
if($cek->num_rows())
{
			$data=$cek->row();
			$isidata=explode(" __v||v__ ",$data->data);
			$row = array();
			$isi="<b>DATA DETAIL REGISTER</b><br> ";
			$jmlKolom=count($isidata);
			for($i=0;$i<($jmlKolom-1);$i++)
			{
			
			if(count(explode("_@-ahref-@_",$isidata[$i]))>1){
				$isiUpload=str_replace("_@-ahref-@_","",$isidata[$i]);
								
		//	$isi="<a target='_blank' href='".base_url()."file_upload/form/".$dataDB->id_admin."_".$dataDB->id_event."/".$isiUpload."'>click to view</a>";
			
			}else
			{
			$isi.=$isidata[$i]." | ";
			}
			
			}
			$isi=substr($isi,0,-2);

			/*------------------------*/

	$q="SELECT * FROM `data_peserta` WHERE `id_admin` = '$idadmin' AND `id_event` = '$u'";
		if($date){
		$q.=" AND substr(tgl,1,10) = '$date' ";
		}else
		{
		$date=date('Y-m-d');
		$q.=" AND substr(tgl,1,10) = '".$this->event->tglAwal($u)."' ";
		}
	$q.="AND `kode_registrasi` = '".$id."' ORDER BY `tgl` DESC";
	$cek=$this->db->query($q)->num_rows();
	$cekidot=$this->db->query($q)->row();
	$sts=isset($cekidot->status)?($cekidot->status):"";
	/*------------------------*/


	if($data->status==0)
	{
			echo "<span class='sadow'><img width='100px' src='".base_url()."plug/img/warning.png'> <br>BELUM TERVERIFIKASI</span>";
	}else
	{
	
	
		if($sts=="1")
		{
			if($cek==0)
			{
				$this->event->updateStatusPeserta2($id,$date);
				echo "<div class='span8'><img width='100px' src='".base_url()."plug/img/cek.png'><br> <span class='sadow'>WELCOME</span> 
				<br><br><font size='5px'> ".$isi."</font> <br>
				<center><hr style='width:30%'>
				".$data->ket."
				</div>";
			}else
			{
				if($sts=="1")
				{
				$this->event->updateStatusPeserta($id);
				echo "<div class='span8'><img width='100px' src='".base_url()."plug/img/cek.png'><br> <span class='sadow'>WELCOME</span> 
				<br><br><font size='5px'> ".$isi."</font> <br>
				<center><hr style='width:30%'>
				".$data->ket."
				</div>";
				}elseif($cekidot->status=="2")
				{
				$this->event->updateStatusPeserta($id);
				echo "<span><img width='100px' src='".base_url()."plug/img/info.png'><br> <span class='sadow'>ID INI TELAH CHECK IN </span><br><br> Last Check-In: ".$data->cekin." 
				<br><br><font size='4px'> ".$isi."</font><br>
				<center><hr style='width:30%'>
				".$data->ket."
				</span>";
				}
			}
			//$this->event->updateStatusPeserta($id);
			
			
		}else
		{
		
			if($sts=="0")
			{
		//	$this->event->updateStatusPeserta($id);
				echo "<span class='sadow'><img width='100px' src='".base_url()."plug/img/warning.png'> <br>BELUM TERVERIFIKASI</span>";
			}	
			elseif($sts=="1")
			{
				$this->event->updateStatusPeserta($id,$date);
				//$this->event->updateStatusPeserta($id);
				echo "<div class='span8'><img width='100px' src='".base_url()."plug/img/cek.png'><br> <span class='sadow'>WELCOME</span> 
				<br><br><font size='5px'> ".$isi."</font> <br>
				<center><hr style='width:30%'>
				".$data->ket."
				</div>";
			}elseif($sts=="2")
			{
				echo "<span><img width='100px' src='".base_url()."plug/img/info.png'><br> <span class='sadow'>ID INI TELAH CHECK IN </span><br><br> Last Check-In: ".$data->cekin." 
				<br><br><font size='4px'> ".$isi."</font><br>
				<center><hr style='width:30%'>
				".$data->ket."
				</span>";
			
			}else
			{
				$this->event->updateStatusPeserta2($id,$date);
				echo "<div class='span8'><img width='100px' src='".base_url()."plug/img/cek.png'><br> <span class='sadow'>WELCOME</span> 
				<br><br><font size='5px'> ".$isi."</font> <br>
				<center><hr style='width:30%'>
				".$data->ket."
				</div>";
			}
		
		
			
		}
		
	}
	
	/*else
	{
		if($cek>0)
		{
			echo "<span><img width='100px' src='".base_url()."plug/img/info.png'><br> <span class='sadow'>ID INI TELAH CHECK IN </span><br><br> Last Check-In: ".$data->cekin." 
			<br><br><font size='4px'> ".$isi."</font><br>
		<center><hr style='width:30%'>
			".$data->ket."
		
			</span>";
		}else
		{
		$this->event->updateStatusPeserta2($id,$date);
			echo "<div class='span8'><img width='100px' src='".base_url()."plug/img/cek.png'><br> <span class='sadow'>WELCOME</span> 
			<br><br><font size='5px'> ".$isi."</font> <br>
			<center><hr style='width:30%'>
			".$data->ket."
			</div>";
		}
			
	}*/
}else
{
echo "<span class='sadow'><img width='100px' src='".base_url()."plug/img/warning.png'> <br><br>".$id." <br> <br> TIDAK TERDAFTAR</span>";
}
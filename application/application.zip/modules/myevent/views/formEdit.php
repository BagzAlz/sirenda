<?php
$dt=$this->event->getType($urut,$idEvent);
$type=$dt->type_form;
$dataDB=$this->db->query("select * from data_peserta where id_admin='".$this->session->userdata("id")."' AND id_event='".$idEvent."' AND id_peserta='".$idPeserta."'  ")->row();
$isidata=explode(" __v||v__ ",$dataDB->data);
$form='<input type="text" name="isi" id="isi" class="form-control" value="'.$isidata[$urut].'"></input>';
if($type==2)
{
$form='<textarea required class="form-control" name="isi" id="isi">'.$isidata[$urut].'</textarea>';
}
if($type==3)
{
	$val="";
	$araypil=$dt->pilihan;
	$data3=explode(",",$araypil);	
	foreach($data3 as $op)
	{
	$val[str_replace(" ","_",$op)]=$op;
	}
	$array=$val;
	$form=form_dropdown("isi",$array,$isidata[$urut], 'class="form-control" id="isi" required');
	
	}
	
if($type==5)
{
$form='<input type="file" required name="isi" class="form-control" id="isi" >';
}
?> 




 <div class="modal-body form">
	 
	  <form action="#" id="form" class="form-horizontal" enctype="multipart/form-data" method="post">
	  <input type="hidden" name="idEvent" value="<?php echo $idEvent?>">
	  <input type="hidden" name="urut" value="<?php echo $urut?>">
	  <input type="hidden" name="idPeserta" value="<?php echo $idPeserta;?>">

       <?php
	  echo $form; 
	   ?>
		
		<br>
		  <div class="modal-footer"> <span id="inforeg1"></span>
		<button class='btn btn-primary' onclick="javascript:saveEdit()">simpan</button>
      </div><!-- /.modal-content -->
	  </form>
	  <script>
	  $(".modal-title-edit").html("<?php echo $dt->nama_form; ?>");
	  </script>
	  	 
<script src="<?php echo base_url('plug/jqueryform/jquery.form.js');?>"></script>
<script>
function saveEdit()
    {
       $('#inforeg1').html("<img src='<?php echo base_url();?>plug/img/load.gif'> <font color='#999999'>Please wait...</font>");
      var  url = "<?php echo base_url();?>myevent/editRegister";
       // ajax adding data to database
          $('#form').ajaxForm({
            url : url,
            type: "POST",
            data: $('#form').serialize(),
            dataType: "JSON",
            success: function(data)
            {
               //if success close modal and reload ajax table
			  $('#form')[0].reset();
			  $('#inforeg1').html("");
			  reload_table()
			  $("#modal_edit").modal("hide");
												
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
              alert('Mohon maaf kami sedang melakukan perbaikan\nTerimakasih atas pengertiannya.');
            }
        });
    }
	
</script>
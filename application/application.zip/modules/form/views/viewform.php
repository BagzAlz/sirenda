<?php
$this->db->order_by("id_form","asc");
	$db=$this->db->get("tampung_form")->result();
	$data="";
	foreach($db as $db)
	{
	if($db->required=="ya"){ $required="required";}else{ $required="";};
	$label=str_replace(" ","_",$db->nama_form);
	if($db->type_form=="2"){
	$data.='	
		<div class="form-group black" style="margin-top:-10px">
		<label for="'.$label.'"><b>'.$db->nama_form.'</b></label>
		<div class="input-group">
		<textarea name="'.$label.'" class="form-control" id="'.$label.'" '.$required.'></textarea>
		<span onclick="del('.$db->id_form.')" class="input-group-addon"><a href="#" class="fa fa-trash" ></a></span>
		</div></div>';
	}
	
	
	
	
	
	
	elseif($db->type_form=="3"){
	$val="";
	$araypil=$db->pilihan;
	$data3=explode(",",$araypil);
	
	
	$data.='<div class="form-group black" style="margin-top:-20px">
		<label for="'.$label.'"><b>'.$db->nama_form.'</b></label>
		<div class="input-group">';
	
	
	foreach($data3 as $op)
	{
	$val[str_replace(" ","_",$op)]=$op;
	}
	$array=$val;
	$data.=form_dropdown($label,$array,"", 'class="form-control"');
	$data.='<span onclick="del('.$db->id_form.')" class="input-group-addon"><a href="#" class="fa fa-trash" ></a></span>
		</div></div>';
	
	
	}
	
	
	
	elseif($db->type_form=="4"){
	$val="";
	$araypil=$db->pilihan;
	$data4=explode(",",$araypil);
	
		
	$data.='	
		<div class="form-group black " style="margin-top:-10px">
		<label><b>'.$db->nama_form.'</b></label>
		<br/>';
		
	foreach($data4 as $op)
	{
	$data.='<div class="checkbox-nice checkbox-inline" >
		<input type="checkbox" id="cek'.str_replace(" ","_",$op).'" name="'.str_replace(" ","_",$op).'"/>
		<label for="cek'.str_replace(" ","_",$op).'">
		'.$op.'
		</label>
		</div>';
	}	
		
		
		
	$data.='<span onclick="del('.$db->id_form.')" class="pull-right"><a class="table-link danger" href="javascript:void()" title="Hapus" onclick="deleted('.$db->id_form.')">
			<span class="fa-stack"><i class="fa fa-square fa-stack-2x"></i><i class="fa fa-trash-o fa-stack-1x fa-inverse"></i>
			</span> </a></span> </div>';
		
	}
	
	
	elseif($db->type_form=="7"){
	$val="";
	$araypil=$db->pilihan;
	$data7=explode(",",$araypil);
	
		
	$data.='	
		<div class="form-group black" style="margin-top:-15px" >
		<label><b>'.$db->nama_form.'</b></label>';
		
	foreach($data7 as $op)
	{
	$data.='<div class="radio">
	<input type="radio" '.$required.' name="'.str_replace(" ","_",$db->nama_form).'" id="ra'.str_replace(" ","_",$op).'" value="'.str_replace(" ","_",$op).'" >
	<label for="ra'.str_replace(" ","_",$op).'">
	<b>'.$op.'</b>
	</label>
	</div>
	';
	}	
		
		
		
	$data.='
	<span style="margin-top:-20px" onclick="del('.$db->id_form.')" class="pull-right">
	<a class="table-link danger" href="javascript:void()" title="Hapus" onclick="deleted('.$db->id_form.')">
	<span class="fa-stack"><i class="fa fa-square fa-stack-2x"></i><i class="fa fa-trash-o fa-stack-1x fa-inverse"></i>	</span> 
	</a>
	</span> 
	</div>';
		
	}elseif($db->type_form=="5"){
		$data.='	
		<div class="form-group black" style="margin-top:-10px">
		<label for="'.$label.'"><b>'.$db->nama_form.'</b></label>
		<div class="input-group">
		<input type="file" name="'.$label.'" class="form-control" id="'.$label.'" '.$required.'>
		<span onclick="del('.$db->id_form.')" class="input-group-addon"><a href="#" class="fa fa-trash" ></a></span>
		</div></div>';
	}elseif($db->type_form=="6"){
		$data.='	
		<div class="form-group black" style="margin-top:-10px">
		<label for="maskedDate"><b>'.$db->nama_form.'</b></label>
		<div class="input-group">
		<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
		<input type="text" class="form-control" name="'.$label.'" id="maskedDate" '.$required.'>
		<span onclick="del('.$db->id_form.')" class="input-group-addon"><a href="#" class="fa fa-trash" ></a></span>
		</div><span class="help-block">ex. tgl/bln/thn</span></div>';
	}else{
	$data.='	
		<div class="form-group black" style="margin-top:-10px">
		<label for="'.$label.'"><b>'.$db->nama_form.'</b></label>
		<div class="input-group">
		<input type="text" name="'.$label.'" class="form-control" id="'.$label.'" '.$required.'>
		<span onclick="del('.$db->id_form.')" class="input-group-addon"><a href="#" class="fa fa-trash" ></a></span>
		</div></div>';
	
	}
	}
	echo json_encode($data);
	?>
	
	
	

	
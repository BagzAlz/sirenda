<?php
$this->db->order_by("id_formulir","asc");
$this->db->where("id_data_form",$idForm);
	$db=$this->db->get("tm_formulir")->result();
	$data="";
	foreach($db as $db)
	{
	if($db->required=="ya"){ $required="required";}else{ $required="";};
	$label=str_replace(" ","_",$db->nama_form);
	if($db->type_form=="2"){
	$data.='	
		<div class="form-group black" style="margin-top:-10px">
		<label for="'.$label.'"><b>'.$db->nama_form.'</b></label>
		<div class="input-group" style="min-width:100%">
		<textarea name="'.$label.'" class="form-control" id="'.$label.'" '.$required.'></textarea>
	
		</div></div>';
	}
	
	
	
	
	
	
	elseif($db->type_form=="3"){
	$val="";
	$araypil=$db->pilihan;
	
	$data3=explode(",",$araypil);
	
	
	$data.='<div class="form-group black" style="margin-top:-20px">
		<label for="'.$label.'"><b>'.$db->nama_form.'</b></label>
		<div class="input-group" style="min-width:100%">';
	
	
	foreach($data3 as $op)
	{
	$val[str_replace(" ","_",$op)]=$op;
	}
	$array=$val;
	$data.=form_dropdown($label,$array,"", 'class="form-control" ');
	$data.='</div></div>';
	
	
	}
	
	
	
	elseif($db->type_form=="4"){
	$val="";
	$araypil=$db->pilihan;
	
	$data4=explode(",",$araypil);
	
		
	$data.='	
		<div class="form-group black " style="margin-top:-10px;min-width:100%">
		<label><b>'.$db->nama_form.'</b></label>
		<br/>';
		
	foreach($data4 as $op)
	{
	$data.='<div class="checkbox-nice checkbox-inline" >
		<input type="checkbox" id="cek'.str_replace(" ","_",$op).'" name="'.str_replace(" ","_",$op).'"/>
		<label for="cek'.str_replace(" ","_",$op).'">
		'.$op.'
		</label>
		</div>';
	}	
		
		
		
	$data.=' </div>';
		
	}
	
	
	elseif($db->type_form=="7"){
	$val="";
	$araypil=$db->pilihan;
	
	$data7=explode(",",$araypil);
	
		
	$data.='	
		<div class="form-group black" style="margin-top:-15px" >
		<label><b>'.$db->nama_form.'</b></label>';
		
	foreach($data7 as $op)
	{
	$data.='<div class="radio">
	<input type="radio" '.$required.' name="'.str_replace(" ","_",$db->nama_form).'" id="ra'.str_replace(" ","_",$op).'" value="'.str_replace(" ","_",$op).'" >
	<label for="ra'.str_replace(" ","_",$op).'">
	<b>'.$op.'</b>
	</label>
	</div>
	';
	}	
		
		
		
	$data.='
	<span style="margin-top:-20px" onclick="del('.$db->id_formulir.')" class="pull-right">
	<a class="table-link danger" href="javascript:void()" title="Hapus" onclick="deleted('.$db->id_formulir.')">
	
	</a>
	</span> 
	</div>';
		
	}elseif($db->type_form=="5"){
		$data.='	
		<div class="form-group black" style="margin-top:-10px">
		<label for="'.$label.'"><b>'.$db->nama_form.'</b></label>
		<div class="input-group" style="min-width:100%">
		<input type="file" name="'.$label.'" class="form-control" id="'.$label.'" '.$required.'>
		
		</div></div>';
	}elseif($db->type_form=="6"){
		$data.='	
		<div class="form-group black" style="margin-top:-10px">
		<label for="maskedDate"><b>'.$db->nama_form.'</b></label>
		<div class="input-group" >
		<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
		<input type="text" class="form-control" name="'.$label.'" id="maskedDate" '.$required.'>
		
		</div><span class="help-block">ex. tgl/bln/thn</span></div>';
	}else{
	$data.='	
		<div class="form-group black" style="margin-top:-10px">
		<label for="'.$label.'"><b>'.$db->nama_form.'</b></label>
		<div class="input-group" style="min-width:100%">
		<input type="text" name="'.$label.'" class="form-control"  id="'.$label.'" '.$required.'>
	
		</div></div>';
	
	}
	}
	echo $data;
	?>
	
	
	

	
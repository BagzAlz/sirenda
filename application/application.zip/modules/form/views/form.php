<script src="<?php echo base_url()?>plug/js/jquery-2.2.1.min.js"></script>
<script src="<?php echo base_url();?>plug/jqueryform/jquery.form.js"></script>

<div class="row" id="user-profile">
<div class="col-lg-6 col-md-6 col-sm-6" >
<div class="main-box clearfix">
<header class="main-box-header clearfix"><center>
<h2><b>Buat Formulir Registrasi</b></h2></center>
</header>
<div class="main-box-body clearfix">
<div class="profile-status">
</div>

<!------->


 <table class="tabel black table-striped  table-hover dataTable tabel-inputan">
                        <thead>
                            <tr>
                                <th>&nbsp;&nbsp;Nama Inputan</th>
                                <th>&nbsp;&nbsp;Type Form</th>
                                <th width='80px'>&nbsp;Wajib isi</th>
                                <th></th>
                            </tr>
                        </thead>
                        <!--elemet sebagai target append-->
                     
                            <tr>
                                <td><input name="namaInput" class="form-control" style='font-size:15px'/></td>
                                <td ><select name="typeInput" id="typeInput" class="form-control" style='font-size:15px'>
									<option value='1'>Text</option>
									<option value='2'>Text Area</option>
									<option value='3'>List Menu</option>
									<option value='4'>Kotak Centang</option>
									<option value='7'>Tombol Pilih</option>
									<option value='5'>Upload</option>
									<option value='6'>Tanggal</option>
									</select></td>
                                <td><select name="required" class="form-control" style='font-size:15px'>
									<option value='1'>Ya</option>
									<option value='2'>Tidak</option>
								</select></td>
                                <td align="right"><button class="simpan btn btn-primary btn-mini" onclick="addForm()";>simpan</button>
								  <button class="btn btn-small btn-primary formPilihan" onclick="simpanitem(); return false"> simpan</button>
								</td>
                            </tr>
                        
                       
                    </table>
<!------->
<hr>
<div id="formPilihan">
<!------>
 <table class="tabel black table-striped  table-hover dataTable tabel-inputan table-condensed">
                        <thead>
                            <tr>
                                <th width="300px">Silahkan tambahkan pilihan:</th>
                                <th width="80px"></th>
                            </tr>
                        </thead>
                        <!--elemet sebagai target append-->
                        
                            <tr>
                                <td><input placeholder='Pilihan ke 1' name="opsi[0]" class="form-control" /></td>
                               
                            </tr>
						<tbody id="itemlist">
                        </tbody>
                        <tfoot>
                            <tr>
                               <td colspan="3">
                                    <button class="btn btn-small btn-primary  pull-right" onclick="additem(); return false"><i class="fa fa-plus-circle"></i> Tambah</button>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
<!------>
</div>
</div>
</div>
</div>

<div class="col-lg-6 col-md-6 col-sm-6 main-box pratampil" >


<?php
$db=$this->db->get("tampung_form")->num_rows();
if($db){;?>
<header class="main-box-header clearfix">
<center><h2><b><span class="titlepra">PREVIEW FORMULIR</span></b></h2>
</header></center>
<div class="main-box-body clearfix">

<span class="form-horizontal">
<div class="kontenpratampil"></div>
</span>

<br>
<button class="btn btn-success pull-right" onclick="finish()"><i class='fa fa-save'></i> simpan</button>
<span id="msg" class="pull-right" style='padding-right:50px;margin-top:5px'></span>
</div>
<?php }else{ ?>

<header class="main-box-header clearfix">
<h2><b><span class="titlepra">TONTON VIDEO PANDUAN </span></b></h2>
</header>

<div class="main-box-body clearfix">
<div id="mobil">
<span class="kontenvideo">
<iframe width="100%" height="315" src="https://www.youtube.com/embed/odETqqocx98" frameborder="0" allowfullscreen></iframe>
</span>

</div>
<br>
<button class="simpanFinsih btn btn-success pull-right" onclick="finish()"><i class='fa fa-save'></i> simpan</button>
</div>

<?php } ?>

</div>





  <link href="<?php echo base_url();?>/plug/datatables/css/dataTables.bootstrap.css" rel="stylesheet">
  <script src="<?php echo base_url()?>plug/datatables/js/jquery.dataTables.min.js"></script>
  <script src="<?php echo base_url()?>plug/datatables/js/dataTables.bootstrap.js"></script>	
  <script>
  $(".simpanFinsih").hide();
 $(document).ready(function() {
 //Ajax Load data from ajax
   loadData();
  });
  function finish()
  {
  $("#finish").modal("show");
  $('.modal-title').text('Langkah Terakhir Pembuatan Formulir Anda!'); // Set title to Bootstrap modal title
  }
  function final()
  {
  var namaF=$("#nama_formulir").val();
  if(namaF=="" || namaF==null){ alert("Isi Nama Formulir"); return false; };
   $(".msg").html("<img src='<?php echo base_url();?>plug/img/load.gif'> Processing...");
	  $.ajax({
        url : "<?php echo base_url();?>form/finishadd",
        type: "POST",
		data:"nama="+namaF,
        dataType: "JSON",
        success: function(data)
        {
		window.location.href="<?php echo base_url();?>form/myform";  
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Silahkan coba lagi!');
        }
		});
  }
  function simpanitem()
  {

   var nama=$("[name='namaInput']").val();
   if(nama=="" || nama==null){ alert("Nama Inputan Mohon di Isi"); return false;}
   var tanya=window.confirm("simpan ?");
   if(tanya==false){ return false;}
 var type=$("[name='typeInput']").val();
 var required=$("[name='required']").val();
  var pilih=pil;
  var ray=""; var kol="";
  data=$('[name="opsi"]').val();
	  for(var x=0;x<pilih;x++)
	  {
	  ray=$('[name="opsi['+x+']"]').val();
	  ray=ray+",";
	  kol=kol+ray;
	  }
	   $(".kontenpratampil").html("<img src='<?php echo base_url();?>plug/img/load.gif'> Processing...");
	  $.ajax({
        url : "<?php echo base_url();?>form/addform",
        type: "GET",
		data:"nama="+nama+"&type="+type+"&required="+required+"&pilih="+kol,
        dataType: "JSON",
        success: function(data)
        {
		var nama=$("[name='typeInput']").val('1');
		var nama=$("[name='namaInput']").val('');
          loadData();     
		  	$("#formPilihan").hide();
		  	$(".formPilihan").hide();
			$(".simpan").show();
		$('[name="opsi[0]"]').val("");  
		$("#itemlist").html("");	
		$(".simpanFinsih").show();		
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Silahkan coba lagi!');
        }
		});
		$("#mobil").html('<span class="form-horizontal"><div class="kontenpratampil"></div></span>');
		  i=0;pil=2;
  }
  
  function loadData(){
     $.ajax({
        url : "<?php echo base_url();?>form/loadData",
		type: "GET",
		data:"",
        dataType: "JSON",
        success: function(data)
        {
          $(".kontenpratampil").html(data);          
          
			  
        }
		});
	}
  </script> 

<script>
	$("#formPilihan").hide();
	$(".formPilihan").hide();
$("[name='typeInput']").change(function(){
var type=$("#typeInput").val();

	if(type==5)
	{
	$("select[name='required']").val(1);
	$("select[name='required']").prop("disabled", true);
	}else
	{
	$("select[name='required']").prop("disabled", false);
	}

	if(type==3 || type==4 || type==7)
	{
	$(".simpan").hide();
	$("#formPilihan").show();
	$(".formPilihan").show();
	}else{
	$(".simpan").show();
	$("#formPilihan").hide();
	$(".formPilihan").hide();
	}
}); 
</script>

  <script>
  function addForm(){
  $(".titlepra").html("<center>PREVIEW FORMULIR</center>");    
 var nama=$("[name='namaInput']").val();
  if(nama=="" || nama==null){ alert("Nama Inputan Mohon di Isi"); return false;}
 $("#mobil").html('<span class="form-horizontal"><div class="kontenpratampil"></div></span>');
 var type=$("[name='typeInput']").val();
 var required=$("[name='required']").val();
 //Ajax Load data from ajax
  $(".kontenpratampil").html("<img src='<?php echo base_url();?>plug/img/load.gif'> Processing...");
      $.ajax({
        url : "<?php echo base_url();?>form/addform",
        type: "GET",
		data:"nama="+nama+"&type="+type+"&required="+required+"&pilih=",
        dataType: "JSON",
        success: function(data)
        {
		var nama=$("[name='namaInput']").val('');
		   loadData();       
		  $(".simpanFinsih").show();	
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Silahkan coba lagi!');
        }
		});
  }
  function del(id)
  {
   $.ajax({
        url : "<?php echo base_url();?>form/delform/"+id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
          loadData();       
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Silahkan coba lagi!');
        }
		});
  
  }
  </script>
  


  <script type="text/javascript">
      var save_method; //for save method string
    var table;
    $(document).ready(function() {
      table = $('#table').DataTable({ 
        
        "processing": true, //Feature control the processing indicator.
        "serverSide": true, //Feature control DataTables' server-side processing mode.
        
        // Load data for the table's content from an Ajax source
        "ajax": {
            "url": "<?php echo site_url('form/ajax_open/'.$this->uri->segment(3).'')?>",
            "type": "POST"
        },

        //Set column definition initialisation properties.
        "columnDefs": [
        { 
          "targets": [ 0,-1 ], //last column
          "orderable": false, //set not orderable
        },
        ],

      });
    });

    function reload_table()
    {
      table.ajax.reload(null,false); //reload datatable ajax 
    }
</script>









 <script>
            var i = 1;
			var pil =2;
            function additem() {
//                menentukan target append
                var itemlist = document.getElementById('itemlist');
                
//                membuat element
                var row = document.createElement('tr');
                var jenis = document.createElement('td');
               
                var aksi = document.createElement('td');

//                meng append element
                itemlist.appendChild(row);
                row.appendChild(jenis);
               
                row.appendChild(aksi);

//                membuat element input
                var opsi = document.createElement('input');
                opsi.setAttribute('name', 'opsi[' + pil + ']');
                opsi.setAttribute('class', 'form-control');
                opsi.setAttribute('placeholder', 'Pilihan ke '+pil);

              
                var hapus = document.createElement('span');

//                meng append element input
                jenis.appendChild(opsi);
               
                aksi.appendChild(hapus);

                hapus.innerHTML = '<button class="btn btn-small btn-danger"><i class="fa fa-trash-o"></i></button>';
//                membuat aksi delete element
                hapus.onclick = function () {
                    row.parentNode.removeChild(row);
					
                };

                i++;
				pil++;
            }
        </script>
		
		
		
		
<!-- Bootstrap modal -->
  <div class="modal fade" id="finish" role="dialog" >
		<div class="modal-dialog">
               <div class="md-content">
				<div class="modal-header">
				<button data-dismiss="modal" class="md-close close">&times;</button>
				<h4 class="modal-title"></h4>
				</div>
				<div class="modal-body">
				
				
	<form class="form-horizontal" id="form" action="javascript:save()">			
					<div class="form-group">
		<label for="nama_formulir" class="black col-lg-3 control-label">Nama Formulir</label>
		 <div class="col-lg-8">
			<input required type="text" class="form-control"  name="nama_formulir" id="nama_formulir" >
		 </div>
	</div>


	
	<div class="form-group">
	 <div class="col-lg-11">
	 <span class="pull-lefts msg"></span>
	<button class="btn btn-success pull-right" onclick="final()"><i class='fa fa-save'></i> simpan</button>
	</div>
	</div>
	
	</form>		
				
				</div>
				</div>
				</div>
         </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
  <!-- End Bootstrap modal -->

<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Form extends CI_Controller {

	

	function __construct()
	{
		parent::__construct();	
		$this->load->model('m_form','form');
		$this->m_konfig->validasi_session(array("user"));
		
	}
	
	function _template($data)
	{
	$this->load->view('template/main',$data);	
	}
	
	public function index()
	{
$reg=$this->session->userdata("reg");
	if($reg) { redirect("myevent/register/$reg"); };
	$data['konten']="form";
	$this->_template($data);
	}
	
	function tampil($id)
	{
	$data['idForm']=$id;
	$this->load->view('tampilform',$data);
	}
	
	function loadData()
	{
	$this->load->view('viewform');
	}
	function delform($id)
	{
	echo $this->form->delform($id);
	}
	
	function addform()
	{
	$data=$this->form->addform();
	echo $data;
	}
	
	public function myform()
	{

	$data['konten']="myform";
	$this->_template($data);
	}
	
	function finishadd()
	{
		echo $this->form->finishadd();
	}
	
	function ajax_open()
	{
			
		$list = $this->form->get_open();
		$data = array();
		$no = $_POST['start'];
		$no =$no+1;
		foreach ($list as $dataDB) {
		////
			$row = array();
			$row[] = "<span class='size'>".$no++."</span>";
			$row[] = "<span class='size'>".$dataDB->nama_form."</span>";
			$row[] = "<span class='size'>".$this->tanggal->hariLengkap($dataDB->tgl,"/")."</span>";
							
			//add html for action
			$row[] = '
			
			<a class="table-link" href="javascript:void()" title="Lihat" onclick="tampil(`'.$dataDB->id_form.'`,`'.$dataDB->nama_form.'`)">
			<span class="fa-stack"><i class="fa fa-square fa-stack-2x"></i><i class="fa fa-eye fa-stack-1x fa-inverse"></i>
			</span> </a>
			
		
			
			
			<a class="table-link danger" href="javascript:void()" title="Hapus" onclick="deleted('.$dataDB->id_form.')">
			<span class="fa-stack"><i class="fa fa-square fa-stack-2x"></i><i class="fa fa-trash-o fa-stack-1x fa-inverse"></i>
			</span> </a>';		
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->form->count_file("data_form"),
						"recordsFiltered" =>$this->form->count_filtered('data_form'),
						"data" => $data,
						);
		//output to json format
		echo json_encode($output);

	}
	
	function deleteForm($id)
	{
	echo $this->form->deleteForm($id);
	}
}


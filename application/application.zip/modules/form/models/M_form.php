<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_form extends ci_Model
{
	
	public function __construct() {
        parent::__construct();
		//$this->m_konfig->validasi_session("super");
     	}
	function get_open()
	{
		
		$query=$this->_get_datatables_open();
		if($_POST['length'] != -1)
		$query.=" limit ".$_POST['start'].",".$_POST['length'];
		return $this->db->query($query)->result();
	}
	private function _get_datatables_open()
	{
	$query="select * from data_form where id_admin='".$this->session->userdata("id")."' ";
	
		
		if($_POST['search']['value']){
		$searchkey=$_POST['search']['value'];
			$query.=" AND (
			nama_form LIKE '%".$searchkey."%'
			) ";
		}

		$column = array('','nama_form','tgl');
		$i=0;
		foreach ($column as $item) 
		{
		$column[$i] = $item;
		}
		
		if(isset($_POST['order']))
		{
		//	$this->db->order_by($column[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
			$query.=" order by ".$column[$_POST['order']['0']['column']]." ".$_POST['order']['0']['dir'] ;
		} 
		else if(isset($order))
		{
			$order = $order;
		//	$this->db->order_by(key($order), $order[key($order)]);
			$query.=" order by ".key($order)." ".$order[key($order)] ;
		}
		return $query;
	
	}
	function delform($id)
	{
	$this->db->where("id_form",$id);
	return $this->db->delete("tampung_form");
	}
	
	public function count_file($tabel)
	{		
		$this->db->where("id_admin",$this->session->userdata("id"));
		$this->db->from($tabel);
		return $this->db->count_all_results();
	}
	function count_filtered($tabel)
	{
		$this->db->where("id_admin",$this->session->userdata("id"));
		$this->db->from($tabel);
		$query=$this->_get_datatables_open();
		return $this->db->query($query)->num_rows();
	}
	function addform()
	{
	$pil=$this->input->get("pilih");
	$pil=substr($pil,0,-1);
	$filter=str_replace(",undefined","",$pil);
	$data=array(
	"id_admin"=>$this->session->userdata("id"),
	"nama_form"=>$this->input->get("nama"),
	"type_form"=>$this->input->get("type"),
	"required"=>$this->input->get("required"),
	"pilihan"=>$filter,
	);
	return $this->db->insert("tampung_form",$data);
	}
	
	private function _gettampung()
	{
	$this->db->order_by("id_form","ASC");
	return $this->db->get("tampung_form")->result();
	}
	
	function incDataForm()
	{
	$data=$this->db->query("SHOW TABLE STATUS LIKE 'data_form'")->row();
	return $data->Auto_increment;
	}
	function finishadd()
	{
	$t=$this->_gettampung();
		foreach($t as $val)
		{
			$array=array(
			"id_admin"=>$this->session->userdata("id"),
			"nama_form"=>$val->nama_form,
			"id_data_form"=>$this->incDataForm(),
			"type_form"=>$val->type_form,
			"required"=>$val->required,
			"pilihan"=>$val->pilihan,
			);
		$this->db->insert("tm_formulir",$array);
		////
		$this->db->where("id_form",$val->id_form);
		$this->db->delete("tampung_form");
		}
		$array=array(
			"id_admin"=>$this->session->userdata("id"),
			"nama_form"=>$this->input->post('nama'),
			"tgl"=>date('Y-m-d'),
			);
	return	$this->db->insert("data_form",$array);
	}
	function deleteForm($id)
	{
	$this->db->where("id_form",$id);
	$this->db->delete("data_form");
	////
	$this->db->where("id_data_form",$id);
	$this->db->delete("tm_formulir");
	}
}

?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_login extends ci_Model
{
	
	public function __construct() {
        parent::__construct();
     	}
	
	function captcha($captcha)
	{
	$this->session->set_userdata(array("captcha"=>$captcha));
	}
	private function cekCaptcha($no)
	{
		$sescap=$this->session->userdata("captcha");
		if($sescap==$no){
		  return 1; 	}else
		{ return 0; 	}
	}
	private function saveSession($id,$level,$pass)
	{
	$array=array(
	"id"=>$id,
	"level"=>$level,
	"pass"=>$pass,
	);
	$this->session->set_userdata($array);
	}
	function getDataLevel($id)//id_level
	{
	$this->db->where("id_level",$id);
	$data=$this->db->get("main_level")->row();
	return $data->nama;
	}
	function cekLogin()
	{	$no=$this->input->post('captcha');
		$cekcap=$this->cekCaptcha($no);
		$this->db->where("username",$this->input->post('username'));
		$this->db->where("password",md5($this->input->post('password')));
		$login=$this->db->get("admin");
		if($login->num_rows()==1)
		{
			$login=$login->row();
			if($cekcap){ $this->saveSession($login->id_admin,$this->getDataLevel($login->level),$this->input->post('password'));  /*success*/ };
			if($cekcap){ return "1_".$this->getDataLevel($login->level);  /*success*/ }else{  return "2_captcha";/*captcha salah*/ };
		}else
		{
			return "0_user/pass";//username/password salah
		}
	}
}

?>
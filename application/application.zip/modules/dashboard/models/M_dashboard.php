<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_dashboard extends ci_Model
{
	
	public function __construct() {
        parent::__construct();
		//$this->m_konfig->validasi_session("super");
     	}
	function dataChat()
	{
	$this->db->order_by("id_chat","ASC");
	return $dataChat=$this->db->get_where("data_chat",array("focus"=>$this->session->userdata("id")))->result();
	}
	//------------------------------------------------------>
	function dataChatMax()
	{
	$this->db->order_by("id_chat","DESC");
	return $dataChat=$this->db->get_where("data_chat",array("focus"=>$this->session->userdata("id")))->row();
	}
	function updateStatusChat()
	{
	$array=array(
	"status"=>"1",
	);
	$this->db->where("id_admin!=",$this->session->userdata("id"));
	$this->db->where("focus",$this->session->userdata("id"));
	return $this->db->update("data_chat",$array);
	}
	
	function sendChat($chat)
	{
	$array=array(
	"id_admin"=>$this->session->userdata("id"),
	"focus"=>$this->session->userdata("id"),
	"chat"=>$chat,
	"date"=>date('Y-m-d H:i:s'),
	);
	return $this->db->insert("data_chat",$array);
	}
	//--------------------------------------------------------------------->
	function jmlEvent()
	{
	$id=$this->session->userdata("id");
	$this->db->where("id_admin",$id);
	return $this->db->get("data_event")->num_rows();
	}function jmlInvoice()
	{
	$id=$this->session->userdata("id");
	$this->db->where("id_admin",$id);
	return $this->db->get("data_invoice")->num_rows();
	}
	function jmlReg()
	{
	$id=$this->session->userdata("id");
	$this->db->where("id_admin",$id);
	return $this->db->get("data_peserta")->num_rows();
	}
	function jmlPeserta($id)
	{
	$ids=$this->session->userdata("id");
	$this->db->where("id_admin",$ids);
	$this->db->where("id_event",$id);
	return $this->db->get("data_peserta")->num_rows();
	}
	function namaForm($id)
	{
	$ids=$this->session->userdata("id");
	$this->db->where("id_admin",$ids);
	$this->db->where("id_form",$id);
	$data=$this->db->get("data_form")->row();
	return isset($data->nama_form)?($data->nama_form):"<i>form dihapus</i>";
	}
	function saldo()
	{
	$id=$this->session->userdata("id");
	$this->db->where("id_admin",$id);
	$data=$this->db->get("admin")->row();
	return $data->saldo;
	}
	function jmlForm()
	{
	$id=$this->session->userdata("id");
	$this->db->where("id_admin",$id);
	$data=$this->db->get("data_form")->num_rows();
	return $data;
	}
	function dataEvent($id)
	{
	$ids=$this->session->userdata("id");
	$this->db->where("id_admin",$ids);
	$this->db->where("id_event",$id);
	return $this->db->get("data_event")->row();
	}
}

?>
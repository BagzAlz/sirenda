<link href='<?php echo base_url();?>assets/css/fullcalendar.css' rel='stylesheet' />
<link href='<?php echo base_url();?>assets/css/fullcalendar.print.css' rel='stylesheet' media='print' />
<script src='<?php echo base_url();?>assets/js/moment.min.js'></script>
<script src='<?php echo base_url();?>assets/js/jquery.min.js'></script>
<script src='<?php echo base_url();?>assets/js/jquery-ui.min.js'></script>
<script src='<?php echo base_url();?>assets/js/fullcalendar.min.js'></script>



<style>
	#trash{
		width:32px;
		height:42px;
		float:left;
		padding-bottom: 15px;
		position: relative;
	}
		
	#wrap {
		width: 1100px;
		margin: 0 auto;
	}
		
	#external-events {
		float: left;
		width: 150px;
		padding: 0 10px;
		border: 1px solid #ccc;
		background: #eee;
		text-align: left;
	}
		
	#external-events h4 {
		font-size: 16px;
		margin-top: 0;
		padding-top: 1em;
	}
		
	#external-events .fc-event {
		margin: 10px 0;
		cursor: pointer;
	}
		
	#external-events p {
		margin: 1.5em 0;
		font-size: 11px;
		color: #666;
	}
		
	#external-events p input {
		margin: 0;
		vertical-align: middle;
	}

	#calendar {
		float: right;
		
	}

</style>

<div class="row" >
<div class="col-lg-12" style='width:99.2%;margin-left:10px'>
<div class="row" >
<div class="col-lg-12">
<div id="content-header" class="clearfix">
<div class="pull-left">
<ol class="breadcrumb sadow05">
<li><a href="#">Home</a></li>
<li class="active"><span>Dashboard</span></li>
</ol>
<h1 class=''>Dashboard</h1>
</div>

</div>
</div>
</div>

<?php
$db=$this->db->query("SELECT DISTINCT(kode_registrasi) as id FROM data_peserta")->result();
$isi2="";
foreach($db as $val)
{
$id=$val->id;
$caraiID=$this->db->query("select id_peserta as id from data_peserta where kode_registrasi='".$id."' ")->row();
$isi2.=$caraiID->id.",";
}
$id_peserta=SUBSTR($isi2,0,-1);
$negara=explode(",",$id_peserta);
$ng=""; $i=0;$namaNegara="";$allData="";

//cari negara
foreach($negara as $nn)
{
$qu="select data from data_peserta where id_peserta='".$nn."'";
$namaData=$this->db->query($qu)->row();
$isidata=explode(" __v||v__ ",$namaData->data);
$allData.=$isidata[0]."::".$nn.",";
}
$allData=SUBSTR($allData,0,-1);
$allData=explode(",",$allData);
foreach($allData as $valid)
{
$pecah=explode("::",$valid);
$country=$pecah[0];
$idp=$pecah[1];
$query="SELECT COUNT(*) AS jml FROM data_peserta WHERE DATA LIKE '".$country."%' AND id_peserta = '".$idp."'";
$db=$this->db->query($query)->row();
$dbjml=$this->db->query($query)->num_rows();
$ng.="{
                name: '".$country."',
                y: ".$dbjml.",
                sliced: true,
                selected: true
            },";
}
?>

<div class="row">


<div class="col-lg-12 col-sm-12 col-xs-12">
<head>
		

		
		<script type="text/javascript">
$(function () {
    $('#containers').highcharts({
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie'
        },
        title: {
            text: 'Negara'
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    format: '<b>{point.name}</b>: {point.percentage:.1f} %',
                    style: {
                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                    }
                }
            }
        },
        series: [{
            name: 'Brands',
            colorByPoint: true,
            data: [
			
			<?php
			echo $ng;
			?>
			
			
			]
        }]
    });
});
		</script>
	</head>
	<body>
<script src="https://code.highcharts.com/highcharts.js"></script>
<div id="containers" style="min-width: 560px;  max-width: 800px; margin: 0 auto"></div>
	</body>
</div>

<!--
<div class="col-lg-3 col-sm-6 col-xs-12">
<div class="main-box infographic-box colored red-bg">
<i class="fa fa-copy"></i>
<span class="headline">Formulir</span>
<span class="value"><?php echo $this->dashboard->jmlForm(); ?></span>
</div>
</div>

<div class="col-lg-3 col-sm-6 col-xs-12">
<div class="main-box infographic-box colored purple-bg">
<i class="fa fa-money"></i>
<span class="headline">Saldo (Rp)</span>
<span class="value">  <?php  $saldo=$this->dashboard->saldo(); echo number_format($saldo,0,",",".");?></span>
</div>
</div>
<div class="col-lg-3 col-sm-6 col-xs-12">
<div class="main-box infographic-box colored blue-bg">
<i class="fa fa-file-text"></i>
<span class="headline">Invoice</span>
<span class="value"><?php echo $this->dashboard->jmlInvoice(); ?></span>
</div>
</div>
</div>
-->


<div class="row">

<div class="col-lg-3 col-sm-6 col-xs-12">
<head>
		

		
		<script type="text/javascript">
$(function () {
    $('#containers').highcharts({
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie'
        },
        title: {
            text: 'Negara'
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    format: '<b>{point.name}</b>: {point.percentage:.1f} %',
                    style: {
                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                    }
                }
            }
        },
        series: [{
            name: 'Brands',
            colorByPoint: true,
            data: [
			
			<?php
			echo $ng;
			?>
			
			
			]
        }]
    });
});
		</script>
	</head>
	<body>
<script src="https://code.highcharts.com/highcharts.js"></script>
<div id="containers" style="width:100%"></div>
	</body>
</div>

<!--
<div class="col-lg-12">
<div class="main-box">
<header class="main-box-header clearfix">
<h2 class="sadow05 black">Kalender Event</h2>
	<div class="toolbar">
		<!----
		<div id='calendar' style="width:98%;padding-right:10px"></div>

		<div style='clear:both'></div>
	
		<!----
	</div>
</header>
<div class="main-box-body clearfix">
<div id="hero-area"></div>
</div>
</div>
</div>


<!----->


</div>
</div>
</div>




<script src="<?php echo base_url();?>plug/boostrap/js/jquery.slimscroll.min.js"></script> 
<script>
function sendChat(){
 $('.nextChat').html("<img src='<?php echo base_url();?>plug/img/load.gif'> <font color='#999999'>Please wait...</font>");
 $('.loadi').html("<img src='<?php echo base_url();?>plug/img/load.gif'> <font color='#999999'>Please wait...</font>");
	var chat=$(".chating").val();
	$.ajax({
	url:"<?php echo base_url();?>dashboard/sendChat",
	type: "POST",
    data: "chat="+chat,
	success: function(data)
            {
			
			$(".nextChat").html(data);
			$(".chating").val("");
			  $(".isicat").removeClass("nextChat");
			   $(".isicat:last").addClass("nextChat");
			   $('.loadi').html("<i><span style='font-size:13px'>Terkirim...</span></i>");
			   
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Try Again!');
            }
	});
}
</script>

	
	

<style>.fc-time{display:none;}</style>
<script>
	$(document).ready(function() {
	$('.conversation-inner').slimScroll({
	        height: '405px',
	        wheelStep: 35,
	    });
	
	
	
  	var zone = "05:30";  //Change this to your timezone

	$.ajax({
		url: '<?php echo base_url();?>dashboard/process',
        type: 'POST', // Send post data
        data: 'type=fetch',
        async: false,
        success: function(s){
        	json_events = s;
        }
	});


	var currentMousePos = {
	    x: -1,
	    y: -1
	};
		jQuery(document).on("mousemove", function (event) {
        currentMousePos.x = event.pageX;
        currentMousePos.y = event.pageY;
    });

		/* initialize the external events
		-----------------------------------------------------------------*/

		$('#external-events .fc-event').each(function() {

			// store data so the calendar knows to render an event upon drop
			$(this).data('event', {
				title: $.trim($(this).text()), // use the element's text as the event title
				stick: true // maintain when user navigates (see docs on the renderEvent method)
			});

			// make the event draggable using jQuery UI
			$(this).draggable({
				zIndex: 999,
				revert: true,      // will cause the event to go back to its
				revertDuration: 0  //  original position after the drag
			});

		});


		/* initialize the calendar
		-----------------------------------------------------------------*/

		$('#calendar').fullCalendar({
			events: JSON.parse(json_events),
			//events: [{"id":"14","title":"New Event","start":"2015-01-24T16:00:00+04:00","allDay":false}],
			utc: false,
			header: {
				left: 'prev,next today',
				center: 'title',
				right: 'month,agendaWeek,agendaDay'
			},
			editable: true,
			droppable: false, 
			slotDuration: '00:30:00',
			eventReceive: function(event){
				var title = event.title;
				var start = event.start.format("YYYY-MM-DD[T]HH:mm:SS");
				$.ajax({
		    		url: '<?php echo base_url();?>dashboard/process',
		    		data: 'type=new&title='+title+'&startdate='+start+'&zone='+zone,
		    		type: 'POST',
		    		dataType: 'json',
		    		success: function(response){
		    			event.id = response.eventid;
		    			$('#calendar').fullCalendar('updateEvent',event);
		    		},
		    		error: function(e){
		    			console.log(e.responseText);

		    		}
		    	});
				$('#calendar').fullCalendar('updateEvent',event);
				console.log(event);
			},
			eventDrop: function(event, delta, revertFunc) {
		        var title = event.title;
		        var start = event.start.format();
		        var end = (event.end == null) ? start : event.end.format();
		        $.ajax({
					url: '<?php echo base_url();?>dashboard/process',
					data: 'type=resetdate&title='+title+'&start='+start+'&end='+end+'&eventid='+event.id,
					type: 'POST',
					dataType: 'json',
					success: function(response){
						if(response.status != 'success')		    				
						revertFunc();
					},
					error: function(e){		    			
						revertFunc();
						alert('Error processing your request: '+e.responseText);
					}
				});
		    },
		    eventClick: function(event, jsEvent, view) {
		    	console.log(event.id);
		         // var title = prompt('Event Title:', event.id, { buttons: { Ok: true, Cancel: false} });
				  detailModal(event.id,event.title);
		          if (title){
		              event.title = title;
		              console.log('type=changetitle&title='+title+'&eventid='+event.id);
		              $.ajax({
				    		url: '<?php echo base_url();?>dashboard/process',
				    		data: 'type=changetitle&title='+title+'&eventid='+event.id,
				    		type: 'POST',
				    		dataType: 'json',
				    		success: function(response){	
				    			if(response.status == 'success')			    			
		              				$('#calendar').fullCalendar('updateEvent',event);
				    		},
				    		error: function(e){
				    			alert('Error processing your request: '+e.responseText);
				    		}
				    	});
		          }
			},
			eventResize: function(event, delta, revertFunc) {
				console.log(event);
				var title = event.title;
				var end = event.end.format();
				var start = event.start.format();
		        $.ajax({
					url: '<?php echo base_url();?>dashboard/process',
					data: 'type=resetdate&title='+title+'&start='+start+'&end='+end+'&eventid='+event.id,
					type: 'POST',
					dataType: 'json',
					success: function(response){
						if(response.status != 'success')		    				
						revertFunc();
					},
					error: function(e){		    			
						revertFunc();
						//alert('Error processing your request: '+e.responseText);
					}
				});
		    },
			eventDragStop: function (event, jsEvent, ui, view) {
			    if (isElemOverDiv()) {
			    	var con = confirm('Are you sure to delete this event permanently?');
			    	if(con == true) {
						$.ajax({
				    		url: '<?php echo base_url();?>dashboard/process',
				    		data: 'type=remove&eventid='+event.id,
				    		type: 'POST',
				    		dataType: 'json',
				    		success: function(response){
				    			console.log(response);
				    			if(response.status == 'success'){
				    				$('#calendar').fullCalendar('removeEvents');
            						getFreshEvents();
            					}
				    		},
				    		error: function(e){	
				    			alert('Error processing your request: '+e.responseText);
				    		}
			    		});
					}   
				}
			}
		});

	function getFreshEvents(){
		$.ajax({
			url: '<?php echo base_url();?>dashboard/process',
	        type: 'POST', // Send post data
	        data: 'type=fetch',
	        async: false,
	        success: function(s){
	        	freshevents = s;
	        }
		});
		$('#calendar').fullCalendar('addEventSource', JSON.parse(freshevents));
	}


	function isElemOverDiv() {
        var trashEl = jQuery('#trash');

        var ofs = trashEl.offset();

        var x1 = ofs.left;
        var x2 = ofs.left + trashEl.outerWidth(true);
        var y1 = ofs.top;
        var y2 = ofs.top + trashEl.outerHeight(true);

        if (currentMousePos.x >= x1 && currentMousePos.x <= x2 &&
            currentMousePos.y >= y1 && currentMousePos.y <= y2) {
            return true;
        }
        return false;
    }

	});
function detailModal(id,title)
{
  // ajax delete data to database
          $.ajax({
            url : "<?php echo base_url();?>dashboard/detailEventModal/"+id,
            type: "POST",
            data: "JSON",
            success: function(data)
            {
              $("#modalEvent").modal("show");
              $(".modal-title").html("<b>"+title+"</b>");
			  $("#dataload").html(data);
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error adding / update data');
            }
        });


}

setInterval(function(){ loadChat(); }, 3000);

function loadChat()
{
	$.ajax({
	url:"<?php echo base_url();?>dashboard/loadChat/",
	type: "POST",
 	success: function(data)
            {
			
			$(".nextChat").html(data);
			  $(".isicat").removeClass("nextChat");
			   $(".isicat:last").addClass("nextChat");
			   			   
            }
	});
}
</script>






<!-- Bootstrap modal -->
  <div class="modal fade" id="modalEvent" role="dialog" >
		<div class="modal-dialog">
               <div class="md-contens">
				
				<div class="modal-body">
				<span id="dataload"></span>
				</div>
				</div>
		</div>
   </div><!-- /.modal-dialog -->
<!-- End Bootstrap modal -->
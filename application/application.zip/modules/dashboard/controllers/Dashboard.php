<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	

	function __construct()
	{
		parent::__construct();	
		$this->load->model('m_dashboard','dashboard');
		$this->m_konfig->validasi_session(array("user"));
		
	}
	
	function _template($data)
	{
	$this->load->view('template/main',$data);	
	}
	function detailEventModal($id)
	{
	$data['id']=$id;
	$this->load->view('detailEvent',$data);	
	}
	public function index()
	{
	
	$data['dataChat']=$this->dashboard->dataChat();
	$data['konten']="dashboard";
	$this->_template($data);
	}
	///////////////////////////////////////
	function loadChat()
	{
	$data['id']="3"; //3=id admin
	$this->load->view("loadChat",$data);
	}
	function sendChat()
	{
	$chat=$this->input->post("chat");
	$this->dashboard->sendChat($chat);
	$data['dataChat']=$this->dashboard->dataChatMax();
	$this->load->view("liveChat",$data);
	}
	//////////////////////////////////////////
	function process()
	{
	/////////////
//	date_default_timezone_set("Asia/Jakarta");
	$type = $_POST['type'];

	if($type == 'new')
	{
		$startdate = $_POST['startdate'].'+'.$_POST['zone'];
		$title = $_POST['title'];
		$insert ="INSERT INTO data_event(`title`, `startdate`, `enddate`, `allDay`) VALUES('$title','$startdate','$startdate','false')";
		$lastid = $this->db->query($insert);
		echo json_encode(array('status'=>'success','eventid'=>$lastid));
	}

	if($type == 'changetitle')
	{
		$eventid = $_POST['eventid'];
		$title = $_POST['title'];
		$update = $this->db->query("UPDATE data_event SET title='$title' where id_event='$eventid'");
		if($update)
			echo json_encode(array('status'=>'success'));
		else
			echo json_encode(array('status'=>'failed'));
	}

	if($type == 'resetdates')
	{
		$title = $_POST['title'];
		$startdate = $_POST['start'];
		$enddate = $_POST['end'];
		$eventid = $_POST['eventid'];
		$update = $this->db->query("UPDATE data_event SET title='$title', startdate = '$startdate', enddate = '$enddate' where id_event='$eventid'");
		if($update)
			echo json_encode(array('status'=>'success'));
		else
			echo json_encode(array('status'=>'failed'));
	}

	if($type == 'remove')
	{
		$eventid = $_POST['eventid'];
		$delete = $this->db->query("DELETE FROM data_event where id_event='$eventid'");
		if($delete)
			echo json_encode(array('status'=>'success'));
		else
			echo json_encode(array('status'=>'failed'));
	}

	if($type == 'fetch')
	{
		$events = array();
		$fetch = $this->db->query("SELECT * FROM data_event where id_admin='".$this->session->userdata('id')."'")->result();
		foreach($fetch as $fetch)
		{
		$e = array();
		$e['id'] = $fetch->id_event;
		$e['title'] = $fetch->title;
		$e['start'] = $fetch->startdate;
		$e['end'] = $fetch->enddate;

		$allday = ($fetch->allDay == "true") ? true : false;
		$e['allDay'] = $allday;

		array_push($events, $e);
		}
		echo json_encode($events);
	}

/////////
	}
	
	//--------------------------->
	function ajax_open()
	{
			
		$list = $this->event->get_open();
		$data = array();
		$no = $_POST['start'];
		$no =$no+1;
		foreach ($list as $dataDB) {
		////
			$row = array();
			
			$row[] = "<span class='size'>".$dataDB->startdate." s.d ".$dataDB->enddate."</span>";
			$row[] = "<span class='size'>".$dataDB->title."</span>";
			$row[] = "<span class='size'>".$dataDB->quota."</span>";
			$row[] = "<span class='size'>ff</span>";
			$row[] = "<span class='size'>".$dataDB->acc."</span>";
			$row[] = "<span class='size'>".$dataDB->batas_registrasi."</span>";
			$row[] = "<span class='size'>".$dataDB->nama_form."</span>";
		
							
			//add html for action
			$row[] = '
			
			<a class="table-link" href="javascript:void()" title="Lihat" onclick="tampil(`'.$dataDB->id_event.'`,`'.$dataDB->id_event.'`)">
			<span class="fa-stack"><i class="fa fa-square fa-stack-2x"></i><i class="fa fa-eye fa-stack-1x fa-inverse"></i>
			</span> </a>
			
			<a class="table-link" href="javascript:void()" title="Edit" onclick="edit('.$dataDB->id_event.')">
			<span class="fa-stack"><i class="fa fa-square fa-stack-2x"></i><i class="fa fa-pencil fa-stack-1x fa-inverse"></i>
			</span> </a>
			
			
			<a class="table-link danger" href="javascript:void()" title="Hapus" onclick="deleted('.$dataDB->id_event.')">
			<span class="fa-stack"><i class="fa fa-square fa-stack-2x"></i><i class="fa fa-trash-o fa-stack-1x fa-inverse"></i>
			</span> </a>';		
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->event->count_file("data_event"),
						"recordsFiltered" =>$this->event->count_filtered('data_event'),
						"data" => $data,
						);
		//output to json format
		echo json_encode($output);

	}
}

